/*
# Create medications and app_settings tables for Just Remember Health

1. New Tables
- `medications` — stores individual medication schedules
  - id (uuid, primary key)
  - name (text, not null) — medication name
  - dosage (text, not null) — dosage amount
  - scheduled_time (time, not null) — time of day to take it
  - frequency (text, not null) — daily, twice_daily, etc.
  - notes (text, nullable) — optional notes
  - color_hex (text, nullable) — display color
  - active (boolean, default true) — whether alarm is active
  - last_taken_at (timestamptz, nullable) — when last verified taken
  - created_at (timestamptz, default now())
  - updated_at (timestamptz, default now())
- `app_settings` — single-row app configuration (single-tenant, no auth)
  - id (uuid, primary key, always row with fixed uuid)
  - dark_mode (boolean, default false)
  - notifications_enabled (boolean, default false)
  - sound_enabled (boolean, default true)
  - vibration_enabled (boolean, default true)
  - snooze_minutes (integer, default 5)
  - created_at (timestamptz, default now())
  - updated_at (timestamptz, default now())

2. Security
- Both tables are single-tenant (no sign-in screen).
- Enable RLS on both.
- Grant CRUD to anon + authenticated so the anon-key frontend can read/write.
- Allow anon + authenticated full CRUD — data is intentionally shared/public.
*/

CREATE TABLE IF NOT EXISTS medications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  dosage text NOT NULL,
  scheduled_time time NOT NULL,
  frequency text NOT NULL DEFAULT 'daily',
  notes text,
  color_hex text DEFAULT '#10b981',
  active boolean NOT NULL DEFAULT true,
  last_taken_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE medications ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON medications TO anon, authenticated;

DROP POLICY IF EXISTS "anon_select_meds" ON medications;
CREATE POLICY "anon_select_meds" ON medications FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_meds" ON medications;
CREATE POLICY "anon_insert_meds" ON medications FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_meds" ON medications;
CREATE POLICY "anon_update_meds" ON medications FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_meds" ON medications;
CREATE POLICY "anon_delete_meds" ON medications FOR DELETE
  TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS app_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  dark_mode boolean NOT NULL DEFAULT false,
  notifications_enabled boolean NOT NULL DEFAULT false,
  sound_enabled boolean NOT NULL DEFAULT true,
  vibration_enabled boolean NOT NULL DEFAULT true,
  snooze_minutes integer NOT NULL DEFAULT 5,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE app_settings ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON app_settings TO anon, authenticated;

DROP POLICY IF EXISTS "anon_select_settings" ON app_settings;
CREATE POLICY "anon_select_settings" ON app_settings FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_settings" ON app_settings;
CREATE POLICY "anon_insert_settings" ON app_settings FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_settings" ON app_settings;
CREATE POLICY "anon_update_settings" ON app_settings FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_settings" ON app_settings;
CREATE POLICY "anon_delete_settings" ON app_settings FOR DELETE
  TO anon, authenticated USING (true);

-- Seed a default settings row if none exists
INSERT INTO app_settings (id, dark_mode, notifications_enabled, sound_enabled, vibration_enabled, snooze_minutes)
SELECT '00000000-0000-0000-0000-000000000001', false, false, true, true, 5
WHERE NOT EXISTS (SELECT 1 FROM app_settings LIMIT 1);
