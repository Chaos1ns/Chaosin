import { useMemo } from 'react';
import { Bell, CheckCircle2, Clock, Pill, Sunrise, Sun, Moon, AlertCircle, Plus } from 'lucide-react';
import type { UpcomingDose } from '../lib/jrhTypes';
import { JrhLogo } from './JrhLogo';

interface TodayScreenProps {
  doses: UpcomingDose[];
  loading: boolean;
  onAddMedication: () => void;
  onTriggerAlarm: (dose: UpcomingDose) => void;
  onMarkTaken: (dose: UpcomingDose) => void;
}

function formatTime(date: Date): string {
  return date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
}

function formatCountdown(minutes: number): string {
  if (minutes < 0) {
    const overdue = Math.abs(minutes);
    if (overdue < 60) return `${overdue} min overdue`;
    const h = Math.floor(overdue / 60);
    const m = overdue % 60;
    return `${h}h ${m}m overdue`;
  }
  if (minutes < 60) return `in ${minutes} min`;
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return `in ${h}h ${m}m`;
}

function getTimeIcon(date: Date) {
  const h = date.getHours();
  if (h < 12) return Sunrise;
  if (h < 18) return Sun;
  return Moon;
}

export function JrhTodayScreen({ doses, loading, onAddMedication, onTriggerAlarm, onMarkTaken }: TodayScreenProps) {
  const grouped = useMemo(() => {
    const now = new Date();
    const upcoming = doses.filter((d) => !d.taken && d.minutesUntil >= -120);
    const taken = doses.filter((d) => d.taken);

    const overdue = upcoming.filter((d) => d.isOverdue);
    const nextUp = upcoming.filter((d) => !d.isOverdue && d.minutesUntil >= 0).slice(0, 5);
    const later = upcoming.filter((d) => !d.isOverdue && d.minutesUntil < 0 && !d.isOverdue);

    return { overdue, nextUp, taken, later };
  }, [doses]);

  const nextDose = grouped.nextUp[0] ?? grouped.overdue[0] ?? null;

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 pb-24">
      {/* Header */}
      <header className="sticky top-0 z-20 bg-white/90 dark:bg-slate-900/90 backdrop-blur-lg border-b border-slate-200/60 dark:border-slate-800/60">
        <div className="mx-auto max-w-lg px-5 py-3 flex items-center justify-between">
          <JrhLogo size="sm" />
          <div className="flex items-center gap-1 text-xs font-medium text-slate-500 dark:text-slate-400">
            <Bell size={14} />
            <span>{new Date().toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}</span>
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-lg px-5 py-5 space-y-5">
        {/* Hero — next dose */}
        {nextDose && !nextDose.taken ? (
          <div className="rounded-3xl bg-gradient-to-br from-jrh-500 to-jrh-700 p-6 shadow-xl shadow-jrh-500/20 text-white animate-slide-up">
            <p className="text-xs font-semibold uppercase tracking-wider text-jrh-100/80">Next Dose</p>
            <div className="mt-2 flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold">{nextDose.medication.name}</h2>
                <p className="text-jrh-100/90 text-sm">{nextDose.medication.dosage}</p>
              </div>
              <div className="text-right">
                <p className="text-3xl font-bold tabular-nums">{formatTime(nextDose.doseTime)}</p>
                <p className="text-jrh-100/80 text-xs">{formatCountdown(nextDose.minutesUntil)}</p>
              </div>
            </div>
            {nextDose.isOverdue && (
              <button
                onClick={() => onTriggerAlarm(nextDose)}
                className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-white/20 py-2.5 text-sm font-bold backdrop-blur-sm transition-all hover:bg-white/30 active:scale-[0.98]"
              >
                <Bell size={16} fill="white" />
                Start Alarm Now
              </button>
            )}
          </div>
        ) : loading ? (
          <div className="rounded-3xl bg-white dark:bg-slate-900 p-6 shadow-sm border border-slate-200/60 dark:border-slate-800 animate-pulse">
            <div className="h-4 w-24 bg-slate-200 dark:bg-slate-700 rounded mb-3" />
            <div className="h-8 w-48 bg-slate-200 dark:bg-slate-700 rounded" />
          </div>
        ) : doses.length === 0 ? (
          <div className="rounded-3xl bg-white dark:bg-slate-900 p-8 text-center shadow-sm border border-slate-200/60 dark:border-slate-800">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-jrh-100 dark:bg-jrh-900/40">
              <Pill size={32} className="text-jrh-500 dark:text-jrh-400" />
            </div>
            <h2 className="mt-4 text-lg font-bold text-slate-800 dark:text-white">No medications yet</h2>
            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">Add your first medication to start tracking.</p>
            <button
              onClick={onAddMedication}
              className="mt-4 flex items-center justify-center gap-2 rounded-xl bg-jrh-500 px-5 py-2.5 text-sm font-bold text-white shadow-md shadow-jrh-500/20 transition-all hover:bg-jrh-600 active:scale-95"
            >
              <Plus size={18} />
              Add Medication
            </button>
          </div>
        ) : (
          <div className="rounded-3xl bg-jrh-50 dark:bg-jrh-900/20 p-6 text-center border border-jrh-200/60 dark:border-jrh-800/40">
            <CheckCircle2 size={36} className="mx-auto text-jrh-500" />
            <h2 className="mt-2 text-lg font-bold text-slate-800 dark:text-white">All done for now!</h2>
            <p className="text-sm text-slate-500 dark:text-slate-400">No upcoming doses. Check back later.</p>
          </div>
        )}

        {/* Overdue */}
        {grouped.overdue.length > 0 && (
          <section>
            <h3 className="flex items-center gap-1.5 px-1 text-sm font-bold text-accent-600 dark:text-accent-400 mb-2">
              <AlertCircle size={16} />
              Overdue
            </h3>
            <div className="space-y-2">
              {grouped.overdue.map((dose, i) => (
                <DoseCard key={i} dose={dose} onTrigger={onTriggerAlarm} onMarkTaken={onMarkTaken} variant="overdue" />
              ))}
            </div>
          </section>
        )}

        {/* Upcoming */}
        {grouped.nextUp.length > 0 && (
          <section>
            <h3 className="flex items-center gap-1.5 px-1 text-sm font-bold text-slate-700 dark:text-slate-200 mb-2">
              <Clock size={16} />
              Upcoming Today
            </h3>
            <div className="space-y-2">
              {grouped.nextUp.map((dose, i) => (
                <DoseCard key={i} dose={dose} onTrigger={onTriggerAlarm} onMarkTaken={onMarkTaken} variant="upcoming" />
              ))}
            </div>
          </section>
        )}

        {/* Taken */}
        {grouped.taken.length > 0 && (
          <section>
            <h3 className="flex items-center gap-1.5 px-1 text-sm font-bold text-slate-500 dark:text-slate-400 mb-2">
              <CheckCircle2 size={16} />
              Completed
            </h3>
            <div className="space-y-2">
              {grouped.taken.map((dose, i) => (
                <DoseCard key={i} dose={dose} onTrigger={onTriggerAlarm} onMarkTaken={onMarkTaken} variant="taken" />
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}

function DoseCard({
  dose,
  onTrigger,
  onMarkTaken,
  variant,
}: {
  dose: UpcomingDose;
  onTrigger: (d: UpcomingDose) => void;
  onMarkTaken: (d: UpcomingDose) => void;
  variant: 'overdue' | 'upcoming' | 'taken';
}) {
  const TimeIcon = getTimeIcon(dose.doseTime);
  const medColor = dose.medication.color_hex ?? '#10b981';

  if (variant === 'taken') {
    return (
      <div className="flex items-center gap-3 rounded-2xl bg-white dark:bg-slate-900 p-3.5 border border-slate-200/60 dark:border-slate-800 opacity-60">
        <div className="flex h-11 w-11 items-center justify-center rounded-xl text-white text-sm font-bold shrink-0" style={{ backgroundColor: medColor }}>
          {dose.medication.name.charAt(0).toUpperCase()}
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold text-slate-600 dark:text-slate-300 truncate line-through">{dose.medication.name}</p>
          <p className="text-xs text-slate-400">{formatTime(dose.doseTime)} — {dose.medication.dosage}</p>
        </div>
        <CheckCircle2 size={20} className="text-jrh-500 shrink-0" />
      </div>
    );
  }

  const isOverdue = variant === 'overdue';

  return (
    <div className={`flex items-center gap-3 rounded-2xl bg-white dark:bg-slate-900 p-3.5 border transition-all ${
      isOverdue
        ? 'border-accent-400/50 shadow-sm shadow-accent-500/10'
        : 'border-slate-200/60 dark:border-slate-800 shadow-sm'
    }`}>
      <div className="flex h-11 w-11 items-center justify-center rounded-xl text-white text-sm font-bold shrink-0" style={{ backgroundColor: medColor }}>
        {dose.medication.name.charAt(0).toUpperCase()}
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-bold text-slate-800 dark:text-white truncate">{dose.medication.name}</p>
        <p className="text-xs text-slate-500 dark:text-slate-400">{dose.medication.dosage}</p>
      </div>
      <div className="text-right shrink-0">
        <div className="flex items-center gap-1 text-sm font-semibold text-slate-700 dark:text-slate-200">
          <TimeIcon size={14} className="text-slate-400" />
          {formatTime(dose.doseTime)}
        </div>
        <p className={`text-xs font-medium ${isOverdue ? 'text-accent-600 dark:text-accent-400' : 'text-slate-400'}`}>
          {formatCountdown(dose.minutesUntil)}
        </p>
      </div>
      {isOverdue && (
        <button
          onClick={() => onTrigger(dose)}
          className="flex h-9 w-9 items-center justify-center rounded-lg bg-accent-500 text-white transition-all hover:bg-accent-600 active:scale-90 shrink-0"
        >
          <Bell size={16} fill="white" />
        </button>
      )}
      {!isOverdue && dose.minutesUntil <= 5 && (
        <button
          onClick={() => onMarkTaken(dose)}
          className="flex h-9 w-9 items-center justify-center rounded-lg bg-jrh-500 text-white transition-all hover:bg-jrh-600 active:scale-90 shrink-0"
        >
          <CheckCircle2 size={16} />
        </button>
      )}
    </div>
  );
}
