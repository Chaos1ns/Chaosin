import { useState, useEffect, useCallback } from 'react';
import { Plus, Trash2, Pencil, X, Pill, Clock, Save, AlertTriangle } from 'lucide-react';
import { jrhSupabase } from '../lib/supabaseClient';
import type { MedicationRecord, FrequencyType } from '../lib/jrhTypes';
import { FREQUENCY_OPTIONS } from '../lib/jrhTypes';
import { JrhLogo } from './JrhLogo';

interface MedsScreenProps {
  meds: MedicationRecord[];
  loading: boolean;
  onRefresh: () => void;
}

const COLOR_CHOICES = [
  '#10b981', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6',
  '#ec4899', '#14b8a6', '#f97316', '#6366f1', '#84cc16',
];

export function JrhMedsScreen({ meds, loading, onRefresh }: MedsScreenProps) {
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<MedicationRecord | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);

  const handleEdit = (med: MedicationRecord) => {
    setEditing(med);
    setShowForm(true);
  };

  const handleCloseForm = () => {
    setShowForm(false);
    setEditing(null);
  };

  const handleSaved = () => {
    handleCloseForm();
    onRefresh();
  };

  const handleDelete = async (id: string) => {
    await jrhSupabase.from('medications').delete().eq('id', id);
    setConfirmDelete(null);
    onRefresh();
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 pb-24">
      <header className="sticky top-0 z-20 bg-white/90 dark:bg-slate-900/90 backdrop-blur-lg border-b border-slate-200/60 dark:border-slate-800/60">
        <div className="mx-auto max-w-lg px-5 py-3 flex items-center justify-between">
          <JrhLogo size="sm" />
          <button
            onClick={() => { setEditing(null); setShowForm(true); }}
            className="flex items-center gap-1.5 rounded-lg bg-jrh-500 px-3 py-1.5 text-sm font-bold text-white shadow-sm transition-all hover:bg-jrh-600 active:scale-95"
          >
            <Plus size={16} />
            Add
          </button>
        </div>
      </header>

      <div className="mx-auto max-w-lg px-5 py-5">
        <h1 className="text-2xl font-bold text-slate-800 dark:text-white mb-1">Medications</h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 mb-5">Manage your pill schedule and alarm times.</p>

        {loading ? (
          <div className="space-y-3">
            {[0, 1, 2].map((i) => (
              <div key={i} className="rounded-2xl bg-white dark:bg-slate-900 p-4 border border-slate-200/60 dark:border-slate-800 animate-pulse">
                <div className="flex gap-3">
                  <div className="h-12 w-12 rounded-xl bg-slate-200 dark:bg-slate-700" />
                  <div className="flex-1 space-y-2">
                    <div className="h-4 w-32 bg-slate-200 dark:bg-slate-700 rounded" />
                    <div className="h-3 w-20 bg-slate-200 dark:bg-slate-700 rounded" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : meds.length === 0 ? (
          <div className="rounded-2xl bg-white dark:bg-slate-900 p-8 text-center border border-slate-200/60 dark:border-slate-800">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-jrh-100 dark:bg-jrh-900/40">
              <Pill size={32} className="text-jrh-500 dark:text-jrh-400" />
            </div>
            <h2 className="mt-4 text-lg font-bold text-slate-800 dark:text-white">No medications yet</h2>
            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">Tap "Add" to create your first medication alarm.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {meds.map((med) => (
              <div key={med.id} className="group rounded-2xl bg-white dark:bg-slate-900 p-4 border border-slate-200/60 dark:border-slate-800 shadow-sm transition-all hover:shadow-md">
                <div className="flex items-center gap-3">
                  <div
                    className="flex h-12 w-12 items-center justify-center rounded-xl text-white font-bold shrink-0"
                    style={{ backgroundColor: med.color_hex ?? '#10b981' }}
                  >
                    {med.name.charAt(0).toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <h3 className="text-sm font-bold text-slate-800 dark:text-white truncate">{med.name}</h3>
                      {!med.active && (
                        <span className="rounded-full bg-slate-200 dark:bg-slate-700 px-2 py-0.5 text-[10px] font-semibold text-slate-500 dark:text-slate-400">
                          Paused
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400">{med.dosage}</p>
                    <div className="mt-1 flex items-center gap-2 text-xs text-slate-400">
                      <Clock size={12} />
                      <span className="font-medium tabular-nums">
                        {formatMedTime(med.scheduled_time)}
                      </span>
                      <span>·</span>
                      <span>{FREQUENCY_OPTIONS.find((f) => f.value === med.frequency)?.label ?? med.frequency}</span>
                    </div>
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <button
                      onClick={() => handleEdit(med)}
                      className="flex h-8 w-8 items-center justify-center rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-300 transition-all hover:bg-slate-200 dark:hover:bg-slate-700 active:scale-90"
                    >
                      <Pencil size={15} />
                    </button>
                    <button
                      onClick={() => setConfirmDelete(med.id)}
                      className="flex h-8 w-8 items-center justify-center rounded-lg bg-red-50 dark:bg-red-900/20 text-red-500 transition-all hover:bg-red-100 dark:hover:bg-red-900/40 active:scale-90"
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>
                </div>
                {med.notes && (
                  <p className="mt-2 pl-15 text-xs text-slate-400 dark:text-slate-500 italic border-l-2 border-slate-200 dark:border-slate-700 pl-3">
                    {med.notes}
                  </p>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Form modal */}
      {showForm && (
        <JrhMedFormModal
          editing={editing}
          onSave={handleSaved}
          onCancel={handleCloseForm}
        />
      )}

      {/* Delete confirm */}
      {confirmDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 animate-fade-in" onClick={() => setConfirmDelete(null)}>
          <div className="w-full max-w-sm rounded-2xl bg-white dark:bg-slate-900 p-6 shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center gap-3 mb-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-red-100 dark:bg-red-900/30">
                <AlertTriangle size={24} className="text-red-500" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-800 dark:text-white">Delete medication?</h3>
                <p className="text-sm text-slate-500 dark:text-slate-400">This cannot be undone.</p>
              </div>
            </div>
            <div className="flex gap-3 mt-4">
              <button
                onClick={() => setConfirmDelete(null)}
                className="flex-1 rounded-xl bg-slate-100 dark:bg-slate-800 py-2.5 text-sm font-semibold text-slate-700 dark:text-slate-200 transition-all hover:bg-slate-200 dark:hover:bg-slate-700"
              >
                Cancel
              </button>
              <button
                onClick={() => handleDelete(confirmDelete)}
                className="flex-1 rounded-xl bg-red-500 py-2.5 text-sm font-bold text-white transition-all hover:bg-red-600 active:scale-95"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function formatMedTime(time: string): string {
  const [h, m] = time.split(':').map(Number);
  const date = new Date();
  date.setHours(h, m, 0, 0);
  return date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
}

function JrhMedFormModal({
  editing,
  onSave,
  onCancel,
}: {
  editing: MedicationRecord | null;
  onSave: () => void;
  onCancel: () => void;
}) {
  const [name, setName] = useState(editing?.name ?? '');
  const [dosage, setDosage] = useState(editing?.dosage ?? '');
  const [time, setTime] = useState(editing?.scheduled_time ?? '08:00');
  const [frequency, setFrequency] = useState<FrequencyType>(editing?.frequency as FrequencyType ?? 'daily');
  const [notes, setNotes] = useState(editing?.notes ?? '');
  const [color, setColor] = useState(editing?.color_hex ?? '#10b981');
  const [active, setActive] = useState(editing?.active ?? true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSave = useCallback(async () => {
    if (!name.trim() || !dosage.trim()) {
      setError('Name and dosage are required.');
      return;
    }

    setSaving(true);
    setError(null);

    const payload = {
      name: name.trim(),
      dosage: dosage.trim(),
      scheduled_time: time,
      frequency,
      notes: notes.trim() || null,
      color_hex: color,
      active,
      updated_at: new Date().toISOString(),
    };

    if (editing) {
      await jrhSupabase.from('medications').update(payload).eq('id', editing.id);
    } else {
      await jrhSupabase.from('medications').insert(payload);
    }

    setSaving(false);
    onSave();
  }, [name, dosage, time, frequency, notes, color, active, editing, onSave]);

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 animate-fade-in" onClick={onCancel}>
      <div
        className="w-full max-w-lg max-h-[90vh] overflow-y-auto rounded-t-3xl sm:rounded-3xl bg-white dark:bg-slate-900 shadow-2xl animate-slide-up"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="sticky top-0 flex items-center justify-between px-5 py-4 bg-white/95 dark:bg-slate-900/95 backdrop-blur border-b border-slate-200/60 dark:border-slate-800">
          <h2 className="text-lg font-bold text-slate-800 dark:text-white">
            {editing ? 'Edit Medication' : 'New Medication'}
          </h2>
          <button
            onClick={onCancel}
            className="flex h-8 w-8 items-center justify-center rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-500 hover:bg-slate-200 dark:hover:bg-slate-700"
          >
            <X size={18} />
          </button>
        </div>

        <div className="p-5 space-y-4">
          {/* Name */}
          <div>
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 uppercase tracking-wide">Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g., Metformin"
              className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-4 py-2.5 text-sm text-slate-800 dark:text-white placeholder:text-slate-400 focus:border-jrh-500 focus:outline-none focus:ring-2 focus:ring-jrh-500/20"
            />
          </div>

          {/* Dosage */}
          <div>
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 uppercase tracking-wide">Dosage</label>
            <input
              type="text"
              value={dosage}
              onChange={(e) => setDosage(e.target.value)}
              placeholder="e.g., 500mg, 1 tablet"
              className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-4 py-2.5 text-sm text-slate-800 dark:text-white placeholder:text-slate-400 focus:border-jrh-500 focus:outline-none focus:ring-2 focus:ring-jrh-500/20"
            />
          </div>

          {/* Time */}
          <div>
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 uppercase tracking-wide">Alarm Time</label>
            <input
              type="time"
              value={time}
              onChange={(e) => setTime(e.target.value)}
              className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-4 py-2.5 text-sm text-slate-800 dark:text-white focus:border-jrh-500 focus:outline-none focus:ring-2 focus:ring-jrh-500/20"
            />
          </div>

          {/* Frequency */}
          <div>
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 uppercase tracking-wide">Frequency</label>
            <div className="mt-1 grid grid-cols-2 gap-2">
              {FREQUENCY_OPTIONS.map((opt) => (
                <button
                  key={opt.value}
                  onClick={() => setFrequency(opt.value)}
                  className={`rounded-xl px-3 py-2.5 text-sm font-medium transition-all ${
                    frequency === opt.value
                      ? 'bg-jrh-500 text-white shadow-sm'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Color */}
          <div>
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 uppercase tracking-wide">Color Tag</label>
            <div className="mt-2 flex flex-wrap gap-2">
              {COLOR_CHOICES.map((c) => (
                <button
                  key={c}
                  onClick={() => setColor(c)}
                  className={`h-8 w-8 rounded-lg transition-all ${color === c ? 'ring-2 ring-offset-2 ring-slate-400 dark:ring-offset-slate-900 scale-110' : ''}`}
                  style={{ backgroundColor: c }}
                />
              ))}
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 uppercase tracking-wide">Notes (optional)</label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g., Take with food"
              rows={2}
              className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-4 py-2.5 text-sm text-slate-800 dark:text-white placeholder:text-slate-400 focus:border-jrh-500 focus:outline-none focus:ring-2 focus:ring-jrh-500/20 resize-none"
            />
          </div>

          {/* Active toggle */}
          <label className="flex items-center justify-between cursor-pointer">
            <span className="text-sm font-medium text-slate-700 dark:text-slate-200">Alarm Active</span>
            <button
              onClick={() => setActive(!active)}
              className={`relative h-6 w-11 rounded-full transition-all ${active ? 'bg-jrh-500' : 'bg-slate-300 dark:bg-slate-700'}`}
            >
              <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all ${active ? 'left-5' : 'left-0.5'}`} />
            </button>
          </label>

          {error && (
            <p className="text-sm text-red-500 font-medium">{error}</p>
          )}

          {/* Save */}
          <button
            onClick={handleSave}
            disabled={saving}
            className="flex w-full items-center justify-center gap-2 rounded-2xl bg-jrh-500 py-3.5 text-base font-bold text-white shadow-lg shadow-jrh-500/20 transition-all hover:bg-jrh-600 active:scale-[0.98] disabled:opacity-50"
          >
            <Save size={20} />
            {saving ? 'Saving...' : editing ? 'Update Medication' : 'Add Medication'}
          </button>
        </div>
      </div>
    </div>
  );
}
