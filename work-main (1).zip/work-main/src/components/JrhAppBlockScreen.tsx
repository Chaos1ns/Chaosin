import { useState, useCallback } from 'react';
import { Lock, Unlock, Instagram, Youtube, Send, Music2, ShieldCheck, X, Camera, CheckCircle2, Sparkles } from 'lucide-react';
import { JrhLogo } from './JrhLogo';

interface AppBlockScreenProps {
  appsUnlocked: boolean;
  onVerify: () => void;
}

interface SocialApp {
  id: string;
  name: string;
  icon: typeof Instagram;
  color: string;
  bgColor: string;
}

const SOCIAL_APPS: SocialApp[] = [
  { id: 'instagram', name: 'Instagram', icon: Instagram, color: 'text-white', bgColor: 'from-purple-500 via-pink-500 to-orange-400' },
  { id: 'tiktok', name: 'TikTok', icon: Music2, color: 'text-white', bgColor: 'from-slate-800 to-slate-900' },
  { id: 'telegram', name: 'Telegram', icon: Send, color: 'text-white', bgColor: 'from-sky-400 to-blue-500' },
  { id: 'youtube', name: 'YouTube', icon: Youtube, color: 'text-white', bgColor: 'from-red-500 to-red-600' },
];

export function JrhAppBlockScreen({ appsUnlocked, onVerify }: AppBlockScreenProps) {
  const [lockedModalApp, setLockedModalApp] = useState<SocialApp | null>(null);
  const [unlockedAnimating, setUnlockedAnimating] = useState(false);

  const handleAppClick = useCallback((app: SocialApp) => {
    if (!appsUnlocked) {
      setLockedModalApp(app);
    }
  }, [appsUnlocked]);

  const handleVerify = useCallback(() => {
    setLockedModalApp(null);
    setUnlockedAnimating(true);
    onVerify();
    setTimeout(() => setUnlockedAnimating(false), 2000);
  }, [onVerify]);

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 pb-24">
      <header className="sticky top-0 z-20 bg-white/90 dark:bg-slate-900/90 backdrop-blur-lg border-b border-slate-200/60 dark:border-slate-800/60">
        <div className="mx-auto max-w-lg px-5 py-3 flex items-center justify-between">
          <JrhLogo size="sm" />
          <div className={`flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-bold ${
            appsUnlocked
              ? 'bg-jrh-100 dark:bg-jrh-900/40 text-jrh-600 dark:text-jrh-400'
              : 'bg-accent-100 dark:bg-accent-900/40 text-accent-600 dark:text-accent-400'
          }`}>
            {appsUnlocked ? <Unlock size={12} /> : <Lock size={12} />}
            {appsUnlocked ? 'Unlocked' : 'Locked'}
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-lg px-5 py-5 space-y-5">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 dark:text-white mb-1">Focus Mode</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            {appsUnlocked
              ? 'Your medication is verified. All apps are unlocked — enjoy!'
              : 'Social apps are locked until you verify your medication. Take your pill to regain access.'}
          </p>
        </div>

        {/* Status banner */}
        <div className={`rounded-2xl p-4 border transition-all ${
          appsUnlocked
            ? 'bg-jrh-50 dark:bg-jrh-900/20 border-jrh-200/60 dark:border-jrh-800/40'
            : 'bg-accent-50 dark:bg-accent-900/20 border-accent-200/60 dark:border-accent-800/40'
        }`}>
          <div className="flex items-center gap-3">
            <div className={`flex h-11 w-11 items-center justify-center rounded-xl shrink-0 ${
              appsUnlocked
                ? 'bg-jrh-500 text-white shadow-lg shadow-jrh-500/20'
                : 'bg-accent-500 text-white shadow-lg shadow-accent-500/20'
            }`}>
              {appsUnlocked ? <ShieldCheck size={22} /> : <Lock size={22} />}
            </div>
            <div className="flex-1">
              <p className={`text-sm font-bold ${appsUnlocked ? 'text-jrh-700 dark:text-jrh-300' : 'text-accent-700 dark:text-accent-300'}`}>
                {appsUnlocked ? 'All Apps Unlocked' : 'Apps Locked by Just Remember Health'}
              </p>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {appsUnlocked
                  ? 'Medication verified. You have full access to your apps.'
                  : 'Complete medication verification to unlock your social apps.'}
              </p>
            </div>
          </div>
          {/* Progress bar */}
          <div className="mt-3 h-1.5 w-full rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-700 ${
                appsUnlocked
                  ? 'bg-gradient-to-r from-jrh-400 to-jrh-500 w-full'
                  : 'bg-gradient-to-r from-accent-400 to-accent-500 w-0'
              }`}
            />
          </div>
        </div>

        {/* App grid */}
        <div className="grid grid-cols-2 gap-3">
          {SOCIAL_APPS.map((app) => {
            const Icon = app.icon;
            return (
              <button
                key={app.id}
                onClick={() => handleAppClick(app)}
                className={`relative rounded-2xl p-4 border transition-all active:scale-95 ${
                  appsUnlocked
                    ? 'bg-white dark:bg-slate-900 border-slate-200/60 dark:border-slate-800 shadow-sm hover:shadow-md'
                    : 'bg-white dark:bg-slate-900 border-slate-200/60 dark:border-slate-800 shadow-sm opacity-80'
                }`}
              >
                {/* Blur overlay when locked */}
                {!appsUnlocked && (
                  <div className="absolute inset-0 rounded-2xl bg-slate-100/30 dark:bg-slate-950/30 backdrop-blur-[2px] flex items-center justify-center">
                    <div className="flex flex-col items-center gap-1">
                      <Lock size={20} className="text-accent-500" />
                      <span className="text-[10px] font-bold text-accent-600 dark:text-accent-400 uppercase tracking-wide">Locked</span>
                    </div>
                  </div>
                )}

                {/* Unlocked glow */}
                {appsUnlocked && (
                  <div className="absolute -top-1 -right-1 flex h-6 w-6 items-center justify-center rounded-full bg-jrh-500 shadow-lg shadow-jrh-500/30">
                    <Unlock size={12} className="text-white" />
                  </div>
                )}

                <div className={`flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br ${app.bgColor} shadow-lg`}>
                  <Icon size={28} className={app.color} />
                </div>
                <p className="mt-2.5 text-sm font-bold text-slate-800 dark:text-white text-left">{app.name}</p>
                <p className={`text-xs font-medium text-left ${appsUnlocked ? 'text-jrh-500 dark:text-jrh-400' : 'text-slate-400'}`}>
                  {appsUnlocked ? 'Available' : 'Tap to see lock'}
                </p>
              </button>
            );
          })}
        </div>

        {/* Verify button when locked */}
        {!appsUnlocked && (
          <button
            onClick={handleVerify}
            className="flex w-full items-center justify-center gap-2 rounded-2xl bg-jrh-500 py-4 text-base font-bold text-white shadow-lg shadow-jrh-500/20 transition-all hover:bg-jrh-600 active:scale-[0.98]"
          >
            <Camera size={22} />
            Verify Medication to Unlock
          </button>
        )}

        {/* Unlock celebration */}
        {unlockedAnimating && (
          <div className="rounded-2xl bg-jrh-500/10 border border-jrh-500/30 p-4 text-center animate-slide-up">
            <div className="flex items-center justify-center gap-2">
              <Sparkles size={20} className="text-jrh-400" />
              <p className="text-sm font-bold text-jrh-600 dark:text-jrh-300">All apps unlocked successfully!</p>
            </div>
          </div>
        )}
      </div>

      {/* Locked modal */}
      {lockedModalApp && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-fade-in"
          onClick={() => setLockedModalApp(null)}
        >
          <div
            className="w-full max-w-sm rounded-3xl bg-white dark:bg-slate-900 p-6 shadow-2xl animate-slide-up"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Lock icon with pulse */}
            <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-accent-100 dark:bg-accent-900/30 mb-4 relative">
              <Lock size={36} className="text-accent-500" />
              <div className="absolute inset-0 rounded-full border-2 border-accent-400/50 animate-ping" />
            </div>

            {/* App name */}
            <div className="flex items-center justify-center gap-2 mb-2">
              <lockedModalApp.icon size={18} className="text-slate-400" />
              <span className="text-sm font-bold text-slate-700 dark:text-slate-200">{lockedModalApp.name}</span>
            </div>

            <h3 className="text-center text-lg font-bold text-slate-800 dark:text-white mb-1">
              Locked by Just Remember Health
            </h3>
            <p className="text-center text-sm text-slate-500 dark:text-slate-400 mb-5">
              Take your pill to unlock access to this app.
            </p>

            <button
              onClick={handleVerify}
              className="flex w-full items-center justify-center gap-2 rounded-2xl bg-jrh-500 py-3.5 text-base font-bold text-white shadow-lg shadow-jrh-500/20 transition-all hover:bg-jrh-600 active:scale-95 mb-2"
            >
              <Camera size={20} />
              Verify Now
            </button>
            <button
              onClick={() => setLockedModalApp(null)}
              className="flex w-full items-center justify-center gap-2 rounded-2xl bg-slate-100 dark:bg-slate-800 py-3 text-sm font-semibold text-slate-600 dark:text-slate-300 transition-all hover:bg-slate-200 dark:hover:bg-slate-700"
            >
              <X size={18} />
              Not Now
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
