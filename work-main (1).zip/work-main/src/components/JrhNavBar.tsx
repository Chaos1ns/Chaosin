import { Home, Pill, Lock, Settings as SettingsIcon, Bell } from 'lucide-react';

export type ScreenName = 'today' | 'medications' | 'focus' | 'settings';

interface NavBarProps {
  current: ScreenName;
  onNavigate: (screen: ScreenName) => void;
  pendingAlarmCount: number;
  appsUnlocked: boolean;
}

export function JrhNavBar({ current, onNavigate, pendingAlarmCount, appsUnlocked }: NavBarProps) {
  const items: Array<{ key: ScreenName; label: string; icon: typeof Home }> = [
    { key: 'today', label: 'Today', icon: Home },
    { key: 'medications', label: 'Meds', icon: Pill },
    { key: 'focus', label: 'Focus', icon: Lock },
    { key: 'settings', label: 'Settings', icon: SettingsIcon },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 border-t border-slate-200/80 bg-white/95 dark:border-slate-800 dark:bg-slate-950/95 backdrop-blur-lg">
      <div className="mx-auto flex max-w-lg items-stretch justify-around px-2 py-1.5">
        {items.map(({ key, label, icon: Icon }) => {
          const isActive = current === key;
          return (
            <button
              key={key}
              onClick={() => onNavigate(key)}
              className={`relative flex flex-1 flex-col items-center gap-0.5 rounded-lg py-2 transition-all duration-200 ${
                isActive
                  ? 'text-jrh-600 dark:text-jrh-400'
                  : 'text-slate-400 hover:text-slate-600 dark:text-slate-500 dark:hover:text-slate-300'
              }`}
            >
              <div className="relative">
                <Icon size={20} strokeWidth={isActive ? 2.5 : 2} />
                {key === 'today' && pendingAlarmCount > 0 && (
                  <span className="absolute -right-2 -top-1 flex h-4 w-4 items-center justify-center rounded-full bg-accent-500 text-[9px] font-bold text-white">
                    {pendingAlarmCount}
                  </span>
                )}
                {key === 'focus' && !appsUnlocked && (
                  <span className="absolute -right-1 -top-1 flex h-2.5 w-2.5 items-center justify-center rounded-full bg-accent-500 ring-2 ring-white dark:ring-slate-950" />
                )}
              </div>
              <span className="text-[11px] font-medium">{label}</span>
              {isActive && (
                <span className="absolute top-0 h-0.5 w-8 rounded-full bg-jrh-500 dark:bg-jrh-400" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
