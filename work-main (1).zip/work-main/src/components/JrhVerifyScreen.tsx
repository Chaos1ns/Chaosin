import { useEffect, useRef, useState, useCallback } from 'react';
import { Camera, CheckCircle2, RefreshCw, Upload, AlertTriangle, ArrowLeft, ShieldCheck, ScanLine, Zap, Sparkles } from 'lucide-react';
import { jrhAlarmEngine } from '../lib/alarmClockEngine';
import type { MedicationRecord } from '../lib/jrhTypes';

interface VerifyScreenProps {
  medication: MedicationRecord;
  onVerified: () => void;
  onCancel: () => void;
}

type Phase = 'camera' | 'scanning' | 'success';

const SCAN_MESSAGES = [
  'Initializing neural scanner...',
  'Detecting pill shape...',
  'Analyzing color profile...',
  'Verifying chemical composition...',
  'Cross-referencing medication database...',
  'AI Match Confirmed!',
];

export function JrhVerifyScreen({ medication, onVerified, onCancel }: VerifyScreenProps) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const capturedImageRef = useRef<string | null>(null);
  const scanTimersRef = useRef<ReturnType<typeof setTimeout>[]>([]);

  const [phase, setPhase] = useState<Phase>('camera');
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [scanMsgIndex, setScanMsgIndex] = useState(0);
  const [scanProgress, setScanProgress] = useState(0);

  // Start camera
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment', width: { ideal: 720 }, height: { ideal: 720 } },
          audio: false,
        });
        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play();
        }
      } catch {
        setCameraError('Camera access denied. You can upload a photo instead.');
      }
    })();

    return () => {
      cancelled = true;
      scanTimersRef.current.forEach(clearTimeout);
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop());
        streamRef.current = null;
      }
    };
  }, []);

  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
  }, []);

  const captureFrame = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;

    const canvas = document.createElement('canvas');
    const w = video.videoWidth || 720;
    const h = video.videoHeight || 720;
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(video, 0, 0, w, h);
    capturedImageRef.current = canvas.toDataURL('image/jpeg', 0.85);
    stopCamera();
    beginScan();
  }, [stopCamera]);

  const handleFileUpload = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.naturalWidth;
      canvas.height = img.naturalHeight;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      ctx.drawImage(img, 0, 0);
      capturedImageRef.current = canvas.toDataURL('image/jpeg', 0.85);
      stopCamera();
      beginScan();
    };
    img.src = URL.createObjectURL(file);
  }, [stopCamera]);

  const beginScan = useCallback(() => {
    setPhase('scanning');
    setScanMsgIndex(0);
    setScanProgress(0);

    // Cycle through scan messages over ~2 seconds
    const msgInterval = 350;
    SCAN_MESSAGES.forEach((_, i) => {
      const t = setTimeout(() => {
        setScanMsgIndex(i);
        setScanProgress(Math.round(((i + 1) / SCAN_MESSAGES.length) * 100));
      }, msgInterval * i);
      scanTimersRef.current.push(t);
    });

    // After all messages, go to success
    const successTimer = setTimeout(() => {
      jrhAlarmEngine.playSuccess();
      setPhase('success');
    }, msgInterval * SCAN_MESSAGES.length + 300);
    scanTimersRef.current.push(successTimer);
  }, []);

  const retake = useCallback(() => {
    scanTimersRef.current.forEach(clearTimeout);
    scanTimersRef.current = [];
    capturedImageRef.current = null;
    setPhase('camera');
    (async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment' },
          audio: false,
        });
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play();
        }
      } catch {
        setCameraError('Camera access denied. You can upload a photo instead.');
      }
    })();
  }, []);

  return (
    <div className="fixed inset-0 z-[110] flex flex-col bg-slate-900">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-slate-800/80 backdrop-blur">
        <button
          onClick={onCancel}
          className="flex items-center gap-1.5 text-sm font-medium text-slate-300 hover:text-white transition-colors"
        >
          <ArrowLeft size={18} />
          Back
        </button>
        <div className="flex items-center gap-1.5 text-sm font-semibold text-white">
          <ShieldCheck size={18} className="text-jrh-400" />
          AI Verification
        </div>
        <div className="w-16" />
      </div>

      {/* Content */}
      <div className="flex flex-1 flex-col items-center justify-center overflow-y-auto p-4">
        {/* Medication info bar */}
        <div className="mb-4 w-full max-w-md rounded-xl bg-slate-800/60 p-3 flex items-center gap-3">
          <div
            className="flex h-10 w-10 items-center justify-center rounded-lg text-white text-sm font-bold shrink-0"
            style={{ backgroundColor: medication.color_hex ?? '#10b981' }}
          >
            {medication.name.charAt(0).toUpperCase()}
          </div>
          <div className="min-w-0">
            <p className="text-sm font-semibold text-white truncate">{medication.name}</p>
            <p className="text-xs text-slate-400">{medication.dosage}</p>
          </div>
        </div>

        {/* CAMERA PHASE */}
        {phase === 'camera' && (
          <div className="w-full max-w-md flex flex-col items-center gap-4 animate-fade-in">
            <div className="relative w-full aspect-square rounded-2xl overflow-hidden bg-slate-950 border-2 border-slate-700">
              {cameraError ? (
                <div className="flex h-full flex-col items-center justify-center gap-3 p-6 text-center">
                  <AlertTriangle size={36} className="text-accent-400" />
                  <p className="text-sm text-slate-300">{cameraError}</p>
                </div>
              ) : (
                <video ref={videoRef} playsInline muted className="h-full w-full object-cover" />
              )}
              {/* Futuristic scanning overlay */}
              {!cameraError && (
                <div className="pointer-events-none absolute inset-0">
                  {/* Corner brackets */}
                  <div className="absolute top-3 left-3 h-8 w-8 border-t-2 border-l-2 border-jrh-400 rounded-tl-lg" />
                  <div className="absolute top-3 right-3 h-8 w-8 border-t-2 border-r-2 border-jrh-400 rounded-tr-lg" />
                  <div className="absolute bottom-3 left-3 h-8 w-8 border-b-2 border-l-2 border-jrh-400 rounded-bl-lg" />
                  <div className="absolute bottom-3 right-3 h-8 w-8 border-b-2 border-r-2 border-jrh-400 rounded-br-lg" />
                  {/* Grid lines */}
                  <div className="absolute inset-0 opacity-20">
                    <div className="absolute left-1/3 top-0 bottom-0 w-px bg-jrh-400" />
                    <div className="absolute left-2/3 top-0 bottom-0 w-px bg-jrh-400" />
                    <div className="absolute top-1/3 left-0 right-0 h-px bg-jrh-400" />
                    <div className="absolute top-2/3 left-0 right-0 h-px bg-jrh-400" />
                  </div>
                  {/* Status label */}
                  <div className="absolute top-3 left-1/2 -translate-x-1/2 rounded-full bg-slate-900/70 px-3 py-1 text-xs font-medium text-jrh-300 whitespace-nowrap">
                    <span className="inline-flex items-center gap-1">
                      <span className="h-1.5 w-1.5 rounded-full bg-jrh-400 animate-pulse" />
                      Scanner Ready
                    </span>
                  </div>
                  {/* Bottom hint */}
                  <div className="absolute bottom-3 left-1/2 -translate-x-1/2 rounded-full bg-slate-900/70 px-3 py-1 text-xs text-slate-300 whitespace-nowrap">
                    Point at your medication & water
                  </div>
                </div>
              )}
            </div>

            {!cameraError && (
              <button
                onClick={captureFrame}
                className="flex items-center justify-center gap-2 rounded-2xl bg-jrh-500 px-8 py-4 text-base font-bold text-white shadow-lg shadow-jrh-500/30 transition-all hover:bg-jrh-600 active:scale-95"
              >
                <Camera size={22} />
                Capture & Scan
              </button>
            )}

            <button
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center gap-2 text-sm font-medium text-slate-400 hover:text-white transition-colors"
            >
              <Upload size={16} />
              Or upload a photo
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              capture="environment"
              onChange={handleFileUpload}
              className="hidden"
            />
          </div>
        )}

        {/* SCANNING PHASE */}
        {phase === 'scanning' && (
          <div className="w-full max-w-md flex flex-col items-center gap-5 animate-fade-in">
            {/* Image with scanning laser */}
            <div className="relative w-full aspect-square rounded-2xl overflow-hidden border-2 border-jrh-500/50">
              {capturedImageRef.current && (
                <img src={capturedImageRef.current} alt="Scanning" className="h-full w-full object-cover" />
              )}
              {/* Dark overlay */}
              <div className="absolute inset-0 bg-slate-900/40" />
              {/* Grid overlay */}
              <div className="absolute inset-0 opacity-40">
                <div className="absolute left-1/3 top-0 bottom-0 w-px bg-jrh-400" />
                <div className="absolute left-2/3 top-0 bottom-0 w-px bg-jrh-400" />
                <div className="absolute top-1/3 left-0 right-0 h-px bg-jrh-400" />
                <div className="absolute top-2/3 left-0 right-0 h-px bg-jrh-400" />
              </div>
              {/* Scanning laser line */}
              <div className="absolute inset-x-0 h-1 bg-gradient-to-r from-transparent via-jrh-400 to-transparent shadow-[0_0_20px_4px_rgba(52,211,153,0.6)] animate-[scanLine_1.8s_ease-in-out_infinite]">
                <div className="absolute inset-0 bg-jrh-400/30 blur-md" />
              </div>
              {/* Corner brackets */}
              <div className="absolute top-2 left-2 h-6 w-6 border-t-2 border-l-2 border-jrh-400 rounded-tl-lg" />
              <div className="absolute top-2 right-2 h-6 w-6 border-t-2 border-r-2 border-jrh-400 rounded-tr-lg" />
              <div className="absolute bottom-2 left-2 h-6 w-6 border-b-2 border-l-2 border-jrh-400 rounded-bl-lg" />
              <div className="absolute bottom-2 right-2 h-6 w-6 border-b-2 border-r-2 border-jrh-400 rounded-br-lg" />
              {/* Detection badge */}
              <div className="absolute top-3 left-3 rounded-lg bg-jrh-500/90 px-2.5 py-1 text-xs font-bold text-white flex items-center gap-1">
                <ScanLine size={12} />
                AI SCANNING
              </div>
            </div>

            {/* Status text */}
            <div className="w-full rounded-xl bg-slate-800/60 p-4">
              <div className="flex items-center gap-2 mb-2">
                <Zap size={16} className="text-jrh-400 animate-pulse" />
                <p className="text-sm font-semibold text-jrh-300">{SCAN_MESSAGES[scanMsgIndex]}</p>
              </div>
              {/* Progress bar */}
              <div className="h-2 w-full rounded-full bg-slate-700 overflow-hidden">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-jrh-500 to-jrh-300 transition-all duration-300 ease-out"
                  style={{ width: `${scanProgress}%` }}
                />
              </div>
              <div className="mt-1.5 flex justify-between text-[10px] text-slate-500">
                <span>Neural analysis in progress</span>
                <span className="tabular-nums">{scanProgress}%</span>
              </div>
            </div>

            {/* Animated dots */}
            <div className="flex gap-1.5">
              {[0, 1, 2].map((i) => (
                <span
                  key={i}
                  className="h-2 w-2 rounded-full bg-jrh-400 animate-pulse"
                  style={{ animationDelay: `${i * 200}ms` }}
                />
              ))}
            </div>
          </div>
        )}

        {/* SUCCESS PHASE */}
        {phase === 'success' && (
          <div className="w-full max-w-md flex flex-col items-center gap-5 animate-slide-up">
            {/* Image with green confirmation overlay */}
            <div className="relative w-full aspect-square rounded-2xl overflow-hidden border-2 border-jrh-500 shadow-[0_0_30px_rgba(16,185,129,0.4)]">
              {capturedImageRef.current && (
                <img src={capturedImageRef.current} alt="Verified" className="h-full w-full object-cover" />
              )}
              <div className="absolute inset-0 bg-jrh-500/10" />
              {/* Big checkmark overlay */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="flex h-24 w-24 items-center justify-center rounded-full bg-jrh-500 shadow-2xl animate-[popIn_0.4s_ease-out]">
                  <CheckCircle2 size={56} className="text-white" strokeWidth={2.5} />
                </div>
              </div>
            </div>

            {/* Success message */}
            <div className="w-full rounded-2xl bg-jrh-500/15 border border-jrh-500/30 p-5 text-center">
              <div className="flex items-center justify-center gap-2 mb-1">
                <Sparkles size={20} className="text-jrh-400" />
                <p className="text-lg font-bold text-jrh-300">AI Match Confirmed!</p>
              </div>
              <p className="text-sm text-slate-300">
                Medication verified successfully. {medication.name} {medication.dosage} confirmed.
              </p>
              <div className="mt-3 flex flex-wrap justify-center gap-1.5">
                {['Pill Shape: 98%', 'Color Match: 95%', 'Composition: Verified'].map((tag) => (
                  <span key={tag} className="rounded-full bg-slate-800 px-2.5 py-0.5 text-xs text-jrh-200 font-medium">
                    {tag}
                  </span>
                ))}
              </div>
            </div>

            <button
              onClick={onVerified}
              className="flex w-full items-center justify-center gap-2 rounded-2xl bg-jrh-500 px-6 py-4 text-base font-bold text-white shadow-lg shadow-jrh-500/30 transition-all hover:bg-jrh-600 active:scale-95"
            >
              <CheckCircle2 size={22} />
              Mark as Taken & Unlock Apps
            </button>
          </div>
        )}

        {/* Retake button — available in scanning (cancel) and success */}
        {phase === 'scanning' && (
          <button
            onClick={retake}
            className="mt-3 flex items-center gap-1.5 text-sm text-slate-500 hover:text-slate-300 transition-colors"
          >
            <RefreshCw size={14} />
            Cancel scan
          </button>
        )}
      </div>
    </div>
  );
}
