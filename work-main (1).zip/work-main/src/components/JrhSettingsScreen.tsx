import { useState, useCallback } from 'react';
import { Moon, Bell, Vibrate, Volume2, Clock, Send, Info, CheckCircle2 } from 'lucide-react';
import { useJrhTheme } from '../lib/jrhTheme';
import { jrhNotifications } from '../lib/notificationService';
import { JrhLogo } from './JrhLogo';

export function JrhSettingsScreen() {
  const {
    darkMode, setDarkMode,
    soundEnabled, setSoundEnabled,
    vibrationEnabled, setVibrationEnabled,
    notificationsEnabled, setNotificationsEnabled,
    snoozeMinutes, setSnoozeMinutes,
  } = useJrhTheme();

  const [notifStatus, setNotifStatus] = useState<string | null>(null);
  const [testSent, setTestSent] = useState(false);

  const handleToggleNotifications = useCallback(async (enable: boolean) => {
    if (enable) {
      const granted = await jrhNotifications.requestPermission();
      if (granted) {
        await setNotificationsEnabled(true);
        setNotifStatus('Notifications enabled — you will receive pill reminders.');
      } else {
        setNotifStatus('Permission denied. Enable notifications in your browser settings.');
      }
    } else {
      await setNotificationsEnabled(false);
      setNotifStatus(null);
    }
  }, [setNotificationsEnabled]);

  const handleTestNotification = useCallback(() => {
    if (jrhNotifications.permission !== 'granted') {
      setNotifStatus('Enable notifications first to test them.');
      return;
    }
    jrhNotifications.sendTest();
    setTestSent(true);
    setTimeout(() => setTestSent(false), 3000);
  }, []);

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 pb-24">
      <header className="sticky top-0 z-20 bg-white/90 dark:bg-slate-900/90 backdrop-blur-lg border-b border-slate-200/60 dark:border-slate-800/60">
        <div className="mx-auto max-w-lg px-5 py-3 flex items-center justify-between">
          <JrhLogo size="sm" />
        </div>
      </header>

      <div className="mx-auto max-w-lg px-5 py-5 space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 dark:text-white mb-1">Settings</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">Customize your alarm and app experience.</p>
        </div>

        {/* Appearance */}
        <SettingsSection title="Appearance" icon={Moon}>
          <SettingsToggle
            icon={Moon}
            label="Dark Mode"
            description="Switch to a deep dark theme for night use"
            value={darkMode}
            onChange={(v) => setDarkMode(v)}
          />
        </SettingsSection>

        {/* Alarm Behavior */}
        <SettingsSection title="Alarm Behavior" icon={Volume2}>
          <SettingsToggle
            icon={Volume2}
            label="Alarm Sound"
            description="Play a loud beep when alarm triggers"
            value={soundEnabled}
            onChange={(v) => setSoundEnabled(v)}
          />
          <SettingsToggle
            icon={Vibrate}
            label="Vibration"
            description="Vibrate the device during alarm"
            value={vibrationEnabled}
            onChange={(v) => setVibrationEnabled(v)}
          />
          <SettingsStepper
            icon={Clock}
            label="Snooze Duration"
            description="Minutes to delay when snoozing"
            value={snoozeMinutes}
            onChange={(v) => setSnoozeMinutes(v)}
            min={1}
            max={30}
            step={1}
          />
        </SettingsSection>

        {/* Notifications */}
        <SettingsSection title="Notifications" icon={Bell}>
          <SettingsToggle
            icon={Bell}
            label="Push Notifications"
            description="Receive browser/phone notifications for pill reminders"
            value={notificationsEnabled}
            onChange={handleToggleNotifications}
          />
          <button
            onClick={handleTestNotification}
            className="flex w-full items-center gap-3 px-4 py-3.5 transition-colors hover:bg-slate-50 dark:hover:bg-slate-800/50"
          >
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-accent-100 dark:bg-accent-900/30 text-accent-600 dark:text-accent-400 shrink-0">
              {testSent ? <CheckCircle2 size={18} /> : <Send size={18} />}
            </div>
            <div className="flex-1 text-left">
              <p className="text-sm font-semibold text-slate-800 dark:text-white">
                {testSent ? 'Test notification sent!' : 'Send Test Notification'}
              </p>
              <p className="text-xs text-slate-500 dark:text-slate-400">Trigger a test reminder now</p>
            </div>
          </button>
          {notifStatus && (
            <p className="px-4 pb-3 text-xs text-slate-500 dark:text-slate-400">{notifStatus}</p>
          )}
          {!jrhNotifications.isSupported && (
            <p className="px-4 pb-3 text-xs text-accent-600 dark:text-accent-400">
              Notifications are not supported on this device.
            </p>
          )}
        </SettingsSection>

        {/* About */}
        <SettingsSection title="About" icon={Info}>
          <div className="px-4 py-3.5 space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-500 dark:text-slate-400">App</span>
              <span className="font-semibold text-slate-800 dark:text-white">Just Remember Health</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-500 dark:text-slate-400">Version</span>
              <span className="font-semibold text-slate-800 dark:text-white">1.0.0</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-500 dark:text-slate-400">AI Verification</span>
              <span className="font-semibold text-slate-800 dark:text-white">On-Device AI Scanner</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-500 dark:text-slate-400">Data Storage</span>
              <span className="font-semibold text-slate-800 dark:text-white">Supabase</span>
            </div>
          </div>
        </SettingsSection>

        <p className="text-center text-xs text-slate-400 dark:text-slate-600 pb-4">
          Just Remember Health — Never forget your medication.
        </p>
      </div>
    </div>
  );
}

function SettingsSection({ title, icon: Icon, children }: { title: string; icon: typeof Moon; children: React.ReactNode }) {
  return (
    <section className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/60 dark:border-slate-800 shadow-sm overflow-hidden">
      <div className="flex items-center gap-2 px-4 py-3 border-b border-slate-200/60 dark:border-slate-800">
        <Icon size={16} className="text-jrh-500 dark:text-jrh-400" />
        <h3 className="text-sm font-bold text-slate-800 dark:text-white">{title}</h3>
      </div>
      <div className="divide-y divide-slate-100 dark:divide-slate-800/60">
        {children}
      </div>
    </section>
  );
}

function SettingsToggle({
  icon: Icon,
  label,
  description,
  value,
  onChange,
}: {
  icon: typeof Moon;
  label: string;
  description: string;
  value: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <div className="flex items-center gap-3 px-4 py-3.5">
      <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-300 shrink-0">
        <Icon size={18} />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-semibold text-slate-800 dark:text-white">{label}</p>
        <p className="text-xs text-slate-500 dark:text-slate-400">{description}</p>
      </div>
      <button
        onClick={() => onChange(!value)}
        className={`relative h-6 w-11 rounded-full transition-all shrink-0 ${
          value ? 'bg-jrh-500' : 'bg-slate-300 dark:bg-slate-700'
        }`}
      >
        <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all ${value ? 'left-5' : 'left-0.5'}`} />
      </button>
    </div>
  );
}

function SettingsStepper({
  icon: Icon,
  label,
  description,
  value,
  onChange,
  min,
  max,
  step,
}: {
  icon: typeof Moon;
  label: string;
  description: string;
  value: number;
  onChange: (v: number) => void;
  min: number;
  max: number;
  step: number;
}) {
  return (
    <div className="flex items-center gap-3 px-4 py-3.5">
      <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-300 shrink-0">
        <Icon size={18} />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-semibold text-slate-800 dark:text-white">{label}</p>
        <p className="text-xs text-slate-500 dark:text-slate-400">{description}</p>
      </div>
      <div className="flex items-center gap-2 shrink-0">
        <button
          onClick={() => onChange(Math.max(min, value - step))}
          className="flex h-7 w-7 items-center justify-center rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-bold transition-all hover:bg-slate-200 dark:hover:bg-slate-700 active:scale-90"
        >
          −
        </button>
        <span className="w-8 text-center text-sm font-bold text-slate-800 dark:text-white tabular-nums">{value}</span>
        <button
          onClick={() => onChange(Math.min(max, value + step))}
          className="flex h-7 w-7 items-center justify-center rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-bold transition-all hover:bg-slate-200 dark:hover:bg-slate-700 active:scale-90"
        >
          +
        </button>
      </div>
    </div>
  );
}
