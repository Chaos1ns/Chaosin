import { Pill } from 'lucide-react';

export function JrhLogo({ size = 'md', showText = true }: { size?: 'sm' | 'md' | 'lg'; showText?: boolean }) {
  const dimensions = {
    sm: { box: 'h-8 w-8', icon: 18, text: 'text-base', sub: 'text-[10px]' },
    md: { box: 'h-10 w-10', icon: 22, text: 'text-lg', sub: 'text-xs' },
    lg: { box: 'h-14 w-14', icon: 32, text: 'text-2xl', sub: 'text-sm' },
  };
  const d = dimensions[size];

  return (
    <div className="flex items-center gap-2.5">
      <div className={`${d.box} rounded-xl bg-gradient-to-br from-jrh-500 to-jrh-700 flex items-center justify-center shadow-lg shadow-jrh-500/30`}>
        <Pill size={d.icon} className="text-white" strokeWidth={2.5} />
      </div>
      {showText && (
        <div className="flex flex-col leading-tight">
          <span className={`${d.text} font-bold tracking-tight text-slate-800 dark:text-white`}>
            Just Remember
          </span>
          <span className={`${d.sub} font-medium tracking-widest uppercase text-jrh-600 dark:text-jrh-400`}>
            Health
          </span>
        </div>
      )}
    </div>
  );
}
