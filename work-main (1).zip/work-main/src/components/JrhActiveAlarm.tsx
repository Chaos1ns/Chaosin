import { useEffect, useState, useCallback } from 'react';
import { Bell, X, Camera, Clock } from 'lucide-react';
import { jrhAlarmEngine } from '../lib/alarmClockEngine';
import { useJrhTheme } from '../lib/jrhTheme';
import type { MedicationRecord } from '../lib/jrhTypes';

interface ActiveAlarmProps {
  medication: MedicationRecord;
  doseTime: Date;
  onDismiss: () => void;
  onSnooze: () => void;
  onVerify: () => void;
}

export function JrhActiveAlarm({ medication, doseTime, onDismiss, onSnooze, onVerify }: ActiveAlarmProps) {
  const { soundEnabled, vibrationEnabled, snoozeMinutes } = useJrhTheme();
  const [snoozing, setSnoozing] = useState(false);
  const [elapsed, setElapsed] = useState(0);

  useEffect(() => {
    jrhAlarmEngine.start({ sound: soundEnabled, vibration: vibrationEnabled });
    return () => jrhAlarmEngine.stop();
  }, [soundEnabled, vibrationEnabled]);

  useEffect(() => {
    const tick = setInterval(() => setElapsed((e) => e + 1), 1000);
    return () => clearInterval(tick);
  }, []);

  const handleSnooze = useCallback(() => {
    jrhAlarmEngine.stop();
    jrhAlarmEngine.playConfirm();
    setSnoozing(true);
    setTimeout(() => {
      setSnoozing(false);
      onSnooze();
    }, 100);
  }, [onSnooze]);

  const formatElapsed = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
  };

  const timeStr = doseTime.toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: '2-digit',
    hour12: true,
  });

  return (
    <div className="fixed inset-0 z-[100] flex flex-col items-center justify-between bg-gradient-to-b from-accent-600 via-accent-700 to-slate-900 p-6 animate-fade-in">
      {/* Pulsing overlay glow */}
      <div className="pointer-events-none absolute inset-0 bg-accent-500/20 animate-glow" />

      {/* Top — alarm label */}
      <div className="relative z-10 flex flex-col items-center gap-2 pt-8">
        <div className="flex h-20 w-20 items-center justify-center rounded-full bg-white/10 backdrop-blur-sm animate-alarm-ring">
          <Bell size={44} className="text-white" fill="white" />
        </div>
        <p className="text-sm font-semibold uppercase tracking-[0.2em] text-accent-200">
          Medication Alarm
        </p>
        <p className="text-5xl font-bold text-white tabular-nums">{timeStr}</p>
        <p className="text-accent-200/80 text-sm">Ringing for {formatElapsed(elapsed)}</p>
      </div>

      {/* Middle — medication info */}
      <div className="relative z-10 mx-auto w-full max-w-sm rounded-2xl bg-white/95 dark:bg-slate-800/95 p-6 shadow-2xl backdrop-blur">
        <div className="flex items-start gap-3">
          <div
            className="flex h-14 w-14 shrink-0 items-center justify-center rounded-xl text-white shadow-lg"
            style={{ backgroundColor: medication.color_hex ?? '#10b981' }}
          >
            <span className="text-2xl font-bold">{medication.name.charAt(0).toUpperCase()}</span>
          </div>
          <div className="flex-1 min-w-0">
            <h2 className="text-xl font-bold text-slate-900 dark:text-white truncate">{medication.name}</h2>
            <p className="text-slate-500 dark:text-slate-300 text-sm">{medication.dosage}</p>
            {medication.notes && (
              <p className="mt-1 text-xs text-slate-400 dark:text-slate-400 italic truncate">{medication.notes}</p>
            )}
          </div>
        </div>
      </div>

      {/* Bottom — actions */}
      <div className="relative z-10 flex w-full max-w-sm flex-col gap-3 pb-8">
        <button
          onClick={onVerify}
          className="flex items-center justify-center gap-2 rounded-2xl bg-jrh-500 px-6 py-4 text-base font-bold text-white shadow-lg shadow-jrh-500/30 transition-all hover:bg-jrh-600 active:scale-[0.98]"
        >
          <Camera size={22} />
          Verify with Camera
        </button>
        <div className="flex gap-3">
          <button
            onClick={handleSnooze}
            disabled={snoozing}
            className="flex flex-1 items-center justify-center gap-2 rounded-2xl bg-white/15 px-4 py-3 text-sm font-semibold text-white backdrop-blur-sm transition-all hover:bg-white/25 active:scale-[0.98] disabled:opacity-50"
          >
            <Clock size={18} />
            Snooze {snoozeMinutes}m
          </button>
          <button
            onClick={() => {
              jrhAlarmEngine.stop();
              jrhAlarmEngine.playConfirm();
              onDismiss();
            }}
            className="flex flex-1 items-center justify-center gap-2 rounded-2xl bg-white/15 px-4 py-3 text-sm font-semibold text-white backdrop-blur-sm transition-all hover:bg-white/25 active:scale-[0.98]"
          >
            <X size={18} />
            Dismiss
          </button>
        </div>
        <p className="text-center text-xs text-accent-200/70">
          Complete verification to dismiss the alarm and mark as taken
        </p>
      </div>
    </div>
  );
}
