/**
 * JrhNotificationService — Web Notifications API wrapper
 * Real browser/phone push notifications for medication reminders.
 */

export const jrhNotifications = {
  async requestPermission(): Promise<boolean> {
    if (!('Notification' in window)) return false;
    if (Notification.permission === 'granted') return true;
    if (Notification.permission === 'denied') return false;
    const result = await Notification.requestPermission();
    return result === 'granted';
  },

  get permission(): NotificationPermission {
    if (!('Notification' in window)) return 'denied';
    return Notification.permission;
  },

  get isSupported(): boolean {
    return typeof window !== 'undefined' && 'Notification' in window;
  },

  /** Send an actual notification for a medication dose */
  send(medName: string, dosage: string, body?: string) {
    if (!('Notification' in window) || Notification.permission !== 'granted') return;
    try {
      const n = new Notification(`Pill Reminder: ${medName}`, {
        body: body ?? `Time to take ${dosage} of ${medName}. Open the app to verify.`,
        icon: '/vite.svg',
        tag: `jrh-med-${medName}`,
        requireInteraction: true,
      });
      n.onclick = () => {
        window.focus();
        n.close();
      };
    } catch {
      // Some browsers throw if notification API is restricted
    }
  },

  /** Send a test notification from Settings */
  sendTest() {
    if (!('Notification' in window) || Notification.permission !== 'granted') return;
    try {
      const n = new Notification('Just Remember Health — Test Notification', {
        body: 'This is a test reminder. Your notifications are working correctly!',
        icon: '/vite.svg',
        tag: 'jrh-test',
        requireInteraction: false,
      });
      setTimeout(() => n.close(), 5000);
    } catch {
      // ignored
    }
  },
};
