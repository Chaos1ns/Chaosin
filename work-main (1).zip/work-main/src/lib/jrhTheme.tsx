import { createContext, useContext, useEffect, useState, useCallback, type ReactNode } from 'react';
import { jrhSupabase } from './supabaseClient';
import type { AppSettingsRecord } from './jrhTypes';

interface ThemeSettings {
  darkMode: boolean;
  soundEnabled: boolean;
  vibrationEnabled: boolean;
  notificationsEnabled: boolean;
  snoozeMinutes: number;
  setDarkMode: (v: boolean) => Promise<void>;
  setSoundEnabled: (v: boolean) => Promise<void>;
  setVibrationEnabled: (v: boolean) => Promise<void>;
  setNotificationsEnabled: (v: boolean) => Promise<void>;
  setSnoozeMinutes: (v: number) => Promise<void>;
  loading: boolean;
}

const JrhThemeCtx = createContext<ThemeSettings | null>(null);

const SETTINGS_ROW_ID = '00000000-0000-0000-0000-000000000001';

export function JrhThemeProvider({ children }: { children: ReactNode }) {
  const [darkMode, setDark] = useState(false);
  const [soundEnabled, setSound] = useState(true);
  const [vibrationEnabled, setVibration] = useState(true);
  const [notificationsEnabled, setNotif] = useState(false);
  const [snoozeMinutes, setSnooze] = useState(5);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const { data, error } = await jrhSupabase
        .from('app_settings')
        .select('*')
        .eq('id', SETTINGS_ROW_ID)
        .maybeSingle();

      if (cancelled) return;

      if (data && !error) {
        const s = data as AppSettingsRecord;
        setDark(s.dark_mode);
        setSound(s.sound_enabled);
        setVibration(s.vibration_enabled);
        setNotif(s.notifications_enabled);
        setSnooze(s.snooze_minutes);
      }
      setLoading(false);
    })();
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    const root = document.documentElement;
    if (darkMode) root.classList.add('dark');
    else root.classList.remove('dark');
  }, [darkMode]);

  const persist = useCallback(async (patch: Partial<AppSettingsRecord>) => {
    await jrhSupabase.from('app_settings').update(patch).eq('id', SETTINGS_ROW_ID);
  }, []);

  const setDarkMode = useCallback(async (v: boolean) => {
    setDark(v);
    await persist({ dark_mode: v, updated_at: new Date().toISOString() });
  }, [persist]);

  const setSoundEnabled = useCallback(async (v: boolean) => {
    setSound(v);
    await persist({ sound_enabled: v, updated_at: new Date().toISOString() });
  }, [persist]);

  const setVibrationEnabled = useCallback(async (v: boolean) => {
    setVibration(v);
    await persist({ vibration_enabled: v, updated_at: new Date().toISOString() });
  }, [persist]);

  const setNotificationsEnabled = useCallback(async (v: boolean) => {
    setNotif(v);
    await persist({ notifications_enabled: v, updated_at: new Date().toISOString() });
  }, [persist]);

  const setSnoozeMinutes = useCallback(async (v: number) => {
    setSnooze(v);
    await persist({ snooze_minutes: v, updated_at: new Date().toISOString() });
  }, [persist]);

  return (
    <JrhThemeCtx.Provider value={{
      darkMode, soundEnabled, vibrationEnabled, notificationsEnabled, snoozeMinutes,
      setDarkMode, setSoundEnabled, setVibrationEnabled, setNotificationsEnabled, setSnoozeMinutes,
      loading,
    }}>
      {children}
    </JrhThemeCtx.Provider>
  );
}

export function useJrhTheme() {
  const ctx = useContext(JrhThemeCtx);
  if (!ctx) throw new Error('useJrhTheme must be used within JrhThemeProvider');
  return ctx;
}
