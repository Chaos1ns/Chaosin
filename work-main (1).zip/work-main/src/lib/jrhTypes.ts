export interface MedicationRecord {
  id: string;
  name: string;
  dosage: string;
  scheduled_time: string;
  frequency: string;
  notes: string | null;
  color_hex: string | null;
  active: boolean;
  last_taken_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface AppSettingsRecord {
  id: string;
  dark_mode: boolean;
  notifications_enabled: boolean;
  sound_enabled: boolean;
  vibration_enabled: boolean;
  snooze_minutes: number;
  created_at: string;
  updated_at: string;
}

export type FrequencyType = 'daily' | 'twice_daily' | 'three_daily' | 'weekly';

export interface FrequencyOption {
  value: FrequencyType;
  label: string;
  intervals: number[];
}

export const FREQUENCY_OPTIONS: FrequencyOption[] = [
  { value: 'daily', label: 'Once daily', intervals: [0] },
  { value: 'twice_daily', label: 'Twice daily', intervals: [0, 12] },
  { value: 'three_daily', label: 'Three times daily', intervals: [0, 8, 16] },
  { value: 'weekly', label: 'Weekly', intervals: [0] },
];

export interface UpcomingDose {
  medication: MedicationRecord;
  doseTime: Date;
  isOverdue: boolean;
  minutesUntil: number;
  taken: boolean;
}
