import { useEffect, useState, useCallback } from 'react';
import type { RefObject } from 'react';
import { jrhSupabase } from './supabaseClient';
import type { MedicationRecord, UpcomingDose } from './jrhTypes';
import { FREQUENCY_OPTIONS } from './jrhTypes';

/** Calculate all dose times for a medication today */
function computeDoseTimes(med: MedicationRecord): Date[] {
  const freq = FREQUENCY_OPTIONS.find((f) => f.value === med.frequency) ?? FREQUENCY_OPTIONS[0];
  const [hours, minutes] = med.scheduled_time.split(':').map(Number);
  const baseTime = new Date();
  baseTime.setHours(hours, minutes, 0, 0);

  if (freq.value === 'weekly') return [baseTime];

  return freq.intervals.map((offset) => {
    const d = new Date(baseTime);
    d.setHours(hours + offset, minutes, 0, 0);
    return d;
  });
}

function isSameHourMinute(a: Date, b: Date): boolean {
  return a.getHours() === b.getHours() && a.getMinutes() === b.getMinutes();
}

export function useMedicationSchedule(
  activeAlarmTime: Date | null,
  verifiedDoseKeysRef: RefObject<Set<string>>,
) {
  const [meds, setMeds] = useState<MedicationRecord[]>([]);
  const [doses, setDoses] = useState<UpcomingDose[]>([]);
  const [loading, setLoading] = useState(true);
  const [nowTick, setNowTick] = useState(0);

  const fetchMeds = useCallback(async () => {
    const { data, error } = await jrhSupabase
      .from('medications')
      .select('*')
      .order('scheduled_time', { ascending: true });

    if (error) {
      setLoading(false);
      return;
    }
    setMeds((data as MedicationRecord[]) ?? []);
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchMeds();
  }, [fetchMeds]);

  // Re-evaluate dose statuses every 30 seconds so past-due doses are detected promptly
  useEffect(() => {
    const interval = setInterval(() => setNowTick((t) => t + 1), 30000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (meds.length === 0) {
      setDoses([]);
      return;
    }

    const now = new Date();
    const todayDoses: UpcomingDose[] = [];

    for (const med of meds) {
      if (!med.active) continue;
      const times = computeDoseTimes(med);
      for (const doseTime of times) {
        const minutesUntil = Math.round((doseTime.getTime() - now.getTime()) / 60000);
        const isOverdue = minutesUntil < 0 && minutesUntil > -120;

        const doseKey = `${med.id}-${doseTime.getTime()}`;

        // Check if already taken (last_taken_at within last 30 min of this dose time)
        let taken = false;
        if (med.last_taken_at) {
          const takenDate = new Date(med.last_taken_at);
          const diffMin = Math.abs(takenDate.getTime() - doseTime.getTime()) / 60000;
          if (diffMin < 35 && takenDate.getTime() > doseTime.getTime() - 60 * 60 * 1000) {
            taken = true;
          }
        }

        // Override: locally-verified doses are always taken, even before DB sync
        if (!taken && verifiedDoseKeysRef.current.has(doseKey)) {
          taken = true;
        }

        todayDoses.push({
          medication: med,
          doseTime,
          isOverdue: isOverdue && !taken,
          minutesUntil,
          taken,
        });
      }
    }

    todayDoses.sort((a, b) => a.doseTime.getTime() - b.doseTime.getTime());
    setDoses(todayDoses);
  }, [meds, activeAlarmTime, nowTick]);

  /** Mark a medication as taken now — optimistic local update, then persist */
  const markTaken = useCallback(async (medId: string) => {
    const nowIso = new Date().toISOString();
    setMeds((prev) =>
      prev.map((m) => (m.id === medId ? { ...m, last_taken_at: nowIso, updated_at: nowIso } : m)),
    );
    // Immediately override the doses array so the Today screen flips to green
    setDoses((prev) =>
      prev.map((d) => {
        const key = `${d.medication.id}-${d.doseTime.getTime()}`;
        if (d.medication.id !== medId || !verifiedDoseKeysRef.current.has(key)) return d;
        return { ...d, taken: true, isOverdue: false };
      }),
    );
    await jrhSupabase
      .from('medications')
      .update({ last_taken_at: nowIso, updated_at: nowIso })
      .eq('id', medId);
    await fetchMeds();
  }, [fetchMeds]);

  return { meds, doses, loading, fetchMeds, markTaken };
}

export { computeDoseTimes, isSameHourMinute };
