/**
 * AlarmClockEngine — persistent alarm using Web Audio API + Vibration
 * Behaves like a real wake-up alarm: loops a loud beep pattern until dismissed.
 */

let audioCtx: AudioContext | null = null;
let alarmInterval: ReturnType<typeof setInterval> | null = null;
let vibrationInterval: ReturnType<typeof setInterval> | null = null;

function ensureAudioCtx(): AudioContext {
  if (!audioCtx) {
    audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

/** Play a single alarm beep — two-tone buzzer sound */
function playBeep(ctx: AudioContext) {
  const now = ctx.currentTime;

  // First tone — high pitch
  const osc1 = ctx.createOscillator();
  const gain1 = ctx.createGain();
  osc1.type = 'square';
  osc1.frequency.setValueAtTime(880, now);
  gain1.gain.setValueAtTime(0, now);
  gain1.gain.linearRampToValueAtTime(0.4, now + 0.01);
  gain1.gain.linearRampToValueAtTime(0, now + 0.25);
  osc1.connect(gain1);
  gain1.connect(ctx.destination);
  osc1.start(now);
  osc1.stop(now + 0.25);

  // Second tone — lower pitch (after a short gap)
  const osc2 = ctx.createOscillator();
  const gain2 = ctx.createGain();
  osc2.type = 'square';
  osc2.frequency.setValueAtTime(660, now + 0.3);
  gain2.gain.setValueAtTime(0, now + 0.3);
  gain2.gain.linearRampToValueAtTime(0.4, now + 0.31);
  gain2.gain.linearRampToValueAtTime(0, now + 0.55);
  osc2.connect(gain2);
  gain2.connect(ctx.destination);
  osc2.start(now + 0.3);
  osc2.stop(now + 0.55);
}

const VIBRATION_PATTERN: number[] = [500, 200, 500, 200, 500, 200, 500, 200, 500, 1000];

export const jrhAlarmEngine = {
  start(opts: { sound: boolean; vibration: boolean } = { sound: true, vibration: true }) {
    this.stop();

    if (opts.sound) {
      const ctx = ensureAudioCtx();
      playBeep(ctx);
      alarmInterval = setInterval(() => playBeep(ctx), 900);
    }

    if (opts.vibration && 'vibrate' in navigator) {
      navigator.vibrate(VIBRATION_PATTERN);
      vibrationInterval = setInterval(() => {
        navigator.vibrate(VIBRATION_PATTERN);
      }, 4000);
    }
  },

  stop() {
    if (alarmInterval) {
      clearInterval(alarmInterval);
      alarmInterval = null;
    }
    if (vibrationInterval) {
      clearInterval(vibrationInterval);
      vibrationInterval = null;
    }
    if ('vibrate' in navigator) {
      navigator.vibrate(0);
    }
  },

  /** Play a short confirmation sound (not alarm — for UI feedback) */
  playConfirm() {
    const ctx = ensureAudioCtx();
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(523, now);
    osc.frequency.linearRampToValueAtTime(784, now + 0.15);
    gain.gain.setValueAtTime(0, now);
    gain.gain.linearRampToValueAtTime(0.25, now + 0.02);
    gain.gain.linearRampToValueAtTime(0, now + 0.3);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.3);
  },

  /** Play a triumphant success sound — for verification pass */
  playSuccess() {
    const ctx = ensureAudioCtx();
    const now = ctx.currentTime;
    const notes = [523, 659, 784, 1047];
    notes.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const start = now + i * 0.12;
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, start);
      gain.gain.setValueAtTime(0, start);
      gain.gain.linearRampToValueAtTime(0.3, start + 0.02);
      gain.gain.linearRampToValueAtTime(0, start + 0.25);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(start);
      osc.stop(start + 0.25);
    });
  },

  /** Play a soft tick — for countdown UI */
  playTick() {
    const ctx = ensureAudioCtx();
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(440, now);
    gain.gain.setValueAtTime(0, now);
    gain.gain.linearRampToValueAtTime(0.1, now + 0.005);
    gain.gain.linearRampToValueAtTime(0, now + 0.08);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.08);
  },
};
