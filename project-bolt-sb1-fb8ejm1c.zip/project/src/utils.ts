import type { Medication } from '@/types';

export function formatTime(time: string): string {
  const [h, m] = time.split(':').map(Number);
  const period = h >= 12 ? 'PM' : 'AM';
  const hour12 = h === 0 ? 12 : h > 12 ? h - 12 : h;
  return `${hour12}:${m.toString().padStart(2, '0')} ${period}`;
}

export function timeToMinutes(time: string): number {
  const [h, m] = time.split(':').map(Number);
  return h * 60 + m;
}

export function getNextMedication(meds: Medication[]): { med: Medication; diffMs: number } | null {
  const now = new Date();
  const nowMin = now.getHours() * 60 + now.getMinutes();
  const active = meds.filter((m) => m.active);
  if (active.length === 0) return null;

  let best: Medication | null = null;
  let bestDiff = Infinity;

  for (const med of active) {
    const medMin = timeToMinutes(med.scheduled_time);
    let diff = medMin - nowMin;
    if (diff <= 0) diff += 24 * 60; // wrap to next day
    if (diff < bestDiff) {
      bestDiff = diff;
      best = med;
    }
  }

  if (!best) return null;
  const diffMs = bestDiff * 60 * 1000 - now.getSeconds() * 1000;
  return { med: best, diffMs };
}

export function formatCountdown(ms: number): { hours: string; minutes: string; seconds: string } {
  if (ms < 0) ms = 0;
  const totalSec = Math.floor(ms / 1000);
  const hours = Math.floor(totalSec / 3600);
  const minutes = Math.floor((totalSec % 3600) / 60);
  const seconds = totalSec % 60;
  return {
    hours: hours.toString().padStart(2, '0'),
    minutes: minutes.toString().padStart(2, '0'),
    seconds: seconds.toString().padStart(2, '0'),
  };
}

export function isOverdue(med: Medication): boolean {
  const now = new Date();
  const nowMin = now.getHours() * 60 + now.getMinutes();
  const medMin = timeToMinutes(med.scheduled_time);
  return nowMin >= medMin && nowMin < medMin + 120; // overdue window of 2 hours
}

export function formatDate(dateStr: string): string {
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

export function formatDateTime(dateStr: string): string {
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) +
    ' at ' +
    d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
}

export function getGreeting(): string {
  const h = new Date().getHours();
  if (h < 12) return 'Good morning';
  if (h < 17) return 'Good afternoon';
  if (h < 21) return 'Good evening';
  return 'Good night';
}
