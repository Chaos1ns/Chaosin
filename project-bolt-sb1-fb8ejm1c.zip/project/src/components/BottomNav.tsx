import { Home, Camera, History, Settings as SettingsIcon } from 'lucide-react';
import type { Screen } from '@/types';

interface Props {
  current: Screen;
  onNavigate: (screen: Screen) => void;
}

export default function BottomNav({ current, onNavigate }: Props) {
  const items: { screen: Screen; icon: typeof Home; label: string }[] = [
    { screen: 'dashboard', icon: Home, label: 'Home' },
    { screen: 'verify', icon: Camera, label: 'Verify' },
    { screen: 'history', icon: History, label: 'History' },
    { screen: 'settings', icon: SettingsIcon, label: 'Settings' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40">
      <div className="max-w-lg mx-auto px-4 pb-4 pt-2">
        <div className="organic-card flex items-center justify-around px-2 py-2.5">
          {items.map((item) => {
            const isActive = current === item.screen;
            const Icon = item.icon;
            return (
              <button
                key={item.screen}
                onClick={() => onNavigate(item.screen)}
                className="relative flex flex-col items-center gap-0.5 px-3 py-1.5 transition-all"
              >
                <div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
                    isActive ? 'bg-sage-500 scale-110' : 'bg-transparent'
                  }`}
                >
                  <Icon
                    className={`w-5 h-5 transition-colors ${
                      isActive ? 'text-white' : 'text-slate-400 dark:text-slate-500'
                    }`}
                  />
                </div>
                <span
                  className={`text-[10px] font-medium transition-colors ${
                    isActive ? 'text-sage-600 dark:text-sage-400' : 'text-slate-400 dark:text-slate-500'
                  }`}
                >
                  {item.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
}
