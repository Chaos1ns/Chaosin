import { useState } from 'react';
import { X, Pill, Check } from 'lucide-react';
import type { Medication, Frequency, MedicationColor } from '@/types';
import { saveMedication } from '@/store';

interface Props {
  medication: Medication | null;
  onClose: () => void;
  onSaved: () => void;
}

const FREQUENCIES: { value: Frequency; label: string }[] = [
  { value: 'daily', label: 'Daily' },
  { value: 'twice-daily', label: 'Twice Daily' },
  { value: 'three-times-daily', label: '3x Daily' },
  { value: 'weekly', label: 'Weekly' },
  { value: 'as-needed', label: 'As Needed' },
];

const COLORS: { value: MedicationColor; label: string; class: string }[] = [
  { value: 'sage', label: 'Sage', class: 'bg-sage-500' },
  { value: 'amber', label: 'Amber', class: 'bg-amber-500' },
  { value: 'slate', label: 'Slate', class: 'bg-slate-500' },
  { value: 'rose', label: 'Rose', class: 'bg-rose-500' },
  { value: 'sky', label: 'Sky', class: 'bg-sky-500' },
];

export default function AddMedicationModal({ medication, onClose, onSaved }: Props) {
  const [name, setName] = useState(medication?.name ?? '');
  const [dosage, setDosage] = useState(medication?.dosage ?? '');
  const [time, setTime] = useState(medication?.scheduled_time ?? '08:00');
  const [frequency, setFrequency] = useState<Frequency>(medication?.frequency ?? 'daily');
  const [notes, setNotes] = useState(medication?.notes ?? '');
  const [color, setColor] = useState<MedicationColor>(medication?.color ?? 'sage');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !dosage.trim()) {
      setError('Please fill in the medication name and dosage.');
      return;
    }
    saveMedication({
      id: medication?.id,
      name: name.trim(),
      dosage: dosage.trim(),
      scheduled_time: time,
      frequency,
      notes: notes.trim() || undefined,
      color,
      active: true,
    });
    onSaved();
  };

  const handleDelete = () => {
    if (medication) {
      saveMedication({ ...medication, active: false });
      onSaved();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center">
      <div
        className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm animate-fade-in dark:bg-black/60"
        onClick={onClose}
      />

      <div className="relative w-full max-w-lg bg-slate-50 dark:bg-slate-900 rounded-t-4xl sm:rounded-4xl max-h-[90vh] overflow-y-auto scrollbar-hide animate-slide-up">
        <div className="sm:hidden w-10 h-1.5 bg-slate-300 dark:bg-slate-700 rounded-full mx-auto mt-3 mb-1" />

        <div className="flex items-center justify-between px-5 py-4 sticky top-0 bg-slate-50 dark:bg-slate-900 z-10">
          <h2 className="text-xl font-serif font-semibold text-slate-800 dark:text-slate-100">
            {medication ? 'Edit Medication' : 'Add Medication'}
          </h2>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-white dark:bg-slate-800 shadow-sm flex items-center justify-center hover:scale-105 transition-transform"
          >
            <X className="w-5 h-5 text-slate-500 dark:text-slate-400" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="px-5 pb-8 space-y-5">
          <div>
            <label className="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-1.5">Medication Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Vitamin D3"
              className="w-full px-4 py-3 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 placeholder:text-slate-300 dark:placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-sage-400 focus:border-transparent"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-1.5">Dosage</label>
            <input
              type="text"
              value={dosage}
              onChange={(e) => setDosage(e.target.value)}
              placeholder="e.g. 500mg, 1 tablet"
              className="w-full px-4 py-3 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 placeholder:text-slate-300 dark:placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-sage-400 focus:border-transparent"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-1.5">Scheduled Time</label>
            <input
              type="time"
              value={time}
              onChange={(e) => setTime(e.target.value)}
              className="w-full px-4 py-3 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-sage-400 focus:border-transparent"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-1.5">Frequency</label>
            <div className="flex flex-wrap gap-2">
              {FREQUENCIES.map((f) => (
                <button
                  key={f.value}
                  type="button"
                  onClick={() => setFrequency(f.value)}
                  className={`px-4 py-2 rounded-xl text-sm font-medium transition-colors ${
                    frequency === f.value
                      ? 'bg-sage-500 text-white'
                      : 'bg-white dark:bg-slate-800 text-slate-500 dark:text-slate-400 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-1.5">Color Label</label>
            <div className="flex gap-3">
              {COLORS.map((c) => (
                <button
                  key={c.value}
                  type="button"
                  onClick={() => setColor(c.value)}
                  className={`relative w-10 h-10 rounded-xl ${c.class} transition-all ${
                    color === c.value ? 'ring-2 ring-offset-2 ring-slate-400 dark:ring-offset-slate-900 scale-110' : ''
                  }`}
                >
                  {color === c.value && <Check className="w-5 h-5 text-white absolute inset-0 m-auto" />}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-1.5">Notes (optional)</label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Take with food"
              rows={2}
              className="w-full px-4 py-3 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 placeholder:text-slate-300 dark:placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-sage-400 focus:border-transparent resize-none"
            />
          </div>

          {error && (
            <p className="text-sm text-rose-500 font-medium">{error}</p>
          )}

          <div className="flex gap-3 pt-2">
            {medication && (
              <button
                type="button"
                onClick={handleDelete}
                className="px-5 py-3.5 rounded-2xl bg-rose-50 dark:bg-rose-900/30 text-rose-500 dark:text-rose-400 font-semibold hover:bg-rose-100 dark:hover:bg-rose-900/50 transition-colors"
              >
                Remove
              </button>
            )}
            <button
              type="submit"
              className="flex-1 px-5 py-3.5 rounded-2xl bg-sage-500 text-white font-semibold hover:bg-sage-600 transition-colors flex items-center justify-center gap-2"
            >
              <Pill className="w-5 h-5" />
              {medication ? 'Save Changes' : 'Add Medication'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
