import { useState, useEffect, useCallback } from 'react';
import {
  Pill, Plus, Clock, CheckCircle2, ChevronRight, Flame, Bell, Lock,
} from 'lucide-react';
import type { Medication } from '@/types';
import { getMedications, isMedicationTakenToday, getSettings } from '@/store';
import { getNextMedication, formatCountdown, formatTime, getGreeting, isOverdue } from '@/utils';

interface Props {
  onNavigate: (screen: 'verify' | 'history' | 'settings' | 'add') => void;
  onSelectMed: (med: Medication) => void;
}

export default function Dashboard({ onNavigate, onSelectMed }: Props) {
  const [meds, setMeds] = useState<Medication[]>([]);
  const [settings, setSettings] = useState(getSettings());
  const [now, setNow] = useState(Date.now());
  const [takenToday, setTakenToday] = useState<Set<string>>(new Set());

  const refresh = useCallback(() => {
    setMeds(getMedications());
    setSettings(getSettings());
    const taken = new Set<string>();
    getMedications().forEach((m) => {
      if (isMedicationTakenToday(m.id)) taken.add(m.id);
    });
    setTakenToday(taken);
  }, []);

  useEffect(() => {
    refresh();
    const interval = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(interval);
  }, [refresh]);

  const next = getNextMedication(meds);
  const activeMeds = meds.filter((m) => m.active);
  const allTaken = activeMeds.length > 0 && activeMeds.every((m) => takenToday.has(m.id));

  const colorMap: Record<string, string> = {
    sage: 'bg-sage-100 text-sage-700 border-sage-200 dark:bg-sage-900/40 dark:text-sage-300 dark:border-sage-800',
    amber: 'bg-amber-100 text-amber-700 border-amber-200 dark:bg-amber-900/30 dark:text-amber-300 dark:border-amber-800',
    slate: 'bg-slate-100 text-slate-700 border-slate-200 dark:bg-slate-700/40 dark:text-slate-300 dark:border-slate-600',
    rose: 'bg-rose-100 text-rose-700 border-rose-200 dark:bg-rose-900/30 dark:text-rose-300 dark:border-rose-800',
    sky: 'bg-sky-100 text-sky-700 border-sky-200 dark:bg-sky-900/30 dark:text-sky-300 dark:border-sky-800',
  };

  const dotColorMap: Record<string, string> = {
    sage: 'bg-sage-500',
    amber: 'bg-amber-500',
    slate: 'bg-slate-500',
    rose: 'bg-rose-500',
    sky: 'bg-sky-500',
  };

  return (
    <div className="min-h-screen pb-32">
      <div className="blob bg-sage-300 w-72 h-72 -top-20 -right-20 dark:bg-sage-800" />
      <div className="blob bg-amber-200 w-64 h-64 top-40 -left-20 dark:bg-amber-900" />

      <div className="relative z-10 max-w-lg mx-auto px-5 pt-10">
        {/* Header */}
        <div className="flex items-center justify-between mb-8 animate-fade-in">
          <div>
            <p className="text-sm text-slate-400 dark:text-slate-500 font-medium">{getGreeting()}</p>
            <h1 className="text-2xl font-serif font-semibold text-slate-800 dark:text-slate-100">Your Ritual</h1>
          </div>
          <button
            onClick={() => onNavigate('settings')}
            className="w-11 h-11 rounded-full bg-white dark:bg-slate-800 shadow-sm flex items-center justify-center hover:scale-105 transition-transform"
          >
            <Bell className="w-5 h-5 text-slate-500 dark:text-slate-400" />
          </button>
        </div>

        {/* Streak badge */}
        <div className="flex items-center gap-2 mb-6 animate-slide-up">
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-amber-100 border border-amber-200 dark:bg-amber-900/30 dark:border-amber-800">
            <Flame className="w-4 h-4 text-amber-600 dark:text-amber-400" />
            <span className="text-sm font-semibold text-amber-700 dark:text-amber-300">{settings.streak_count} day streak</span>
          </div>
          {settings.focus_mode === 'strict' && (
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-100 border border-slate-200 dark:bg-slate-800 dark:border-slate-700">
              <Lock className="w-3.5 h-3.5 text-slate-600 dark:text-slate-400" />
              <span className="text-sm font-semibold text-slate-600 dark:text-slate-300">Strict Mode</span>
            </div>
          )}
        </div>

        {/* Next pill countdown card */}
        {next ? (
          <div
            className={`organic-card-dark p-6 mb-6 animate-scale-in relative overflow-hidden ${
              allTaken ? 'opacity-70' : ''
            }`}
          >
            <div className="absolute top-0 right-0 w-32 h-32 bg-sage-500/20 dark:bg-sage-500/10 rounded-full blur-3xl" />
            <div className="relative z-10">
              <div className="flex items-center gap-2 mb-1">
                {allTaken ? (
                  <CheckCircle2 className="w-5 h-5 text-sage-400" />
                ) : (
                  <Clock className="w-5 h-5 text-amber-400" />
                )}
                <p className="text-sm font-medium text-slate-300 dark:text-slate-400">
                  {allTaken ? 'All pills taken today' : 'Next pill in'}
                </p>
              </div>
              {!allTaken && (
                <div className="flex items-end gap-1 mb-3">
                  {(() => {
                    const c = formatCountdown(next.diffMs - (Date.now() - now));
                    return (
                      <>
                        <CountdownUnit value={c.hours} label="hrs" />
                        <span className="text-3xl font-bold text-slate-500 mb-3">:</span>
                        <CountdownUnit value={c.minutes} label="min" />
                        <span className="text-3xl font-bold text-slate-500 mb-3">:</span>
                        <CountdownUnit value={c.seconds} label="sec" />
                      </>
                    );
                  })()}
                </div>
              )}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-full ${dotColorMap[next.med.color] || 'bg-sage-500'} flex items-center justify-center`}>
                    <Pill className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p className="font-semibold text-white text-lg">{next.med.name}</p>
                    <p className="text-sm text-slate-400">{next.med.dosage} • {formatTime(next.med.scheduled_time)}</p>
                  </div>
                </div>
                {!allTaken && (
                  <button
                    onClick={() => onSelectMed(next.med)}
                    className="px-4 py-2.5 rounded-2xl bg-sage-500 hover:bg-sage-400 text-white text-sm font-semibold transition-colors flex items-center gap-1.5"
                  >
                    Verify & Take
                    <ChevronRight className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          </div>
        ) : (
          <div className="organic-card p-6 mb-6 text-center">
            <p className="text-slate-400 dark:text-slate-500">No medications scheduled. Add one to get started.</p>
          </div>
        )}

        {/* Today's schedule */}
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-serif font-semibold text-slate-700 dark:text-slate-200">Today's Schedule</h2>
          <button
            onClick={() => onNavigate('history')}
            className="text-sm text-sage-600 dark:text-sage-400 font-medium hover:text-sage-700 dark:hover:text-sage-300"
          >
            History
          </button>
        </div>

        <div className="space-y-3">
          {activeMeds.length === 0 && (
            <div className="organic-card p-8 text-center">
              <Pill className="w-10 h-10 text-slate-300 dark:text-slate-600 mx-auto mb-3" />
              <p className="text-slate-400 dark:text-slate-500 text-sm mb-4">No medications yet</p>
              <button
                onClick={() => onNavigate('add')}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-sage-500 text-white text-sm font-medium hover:bg-sage-600 transition-colors"
              >
                <Plus className="w-4 h-4" /> Add medication
              </button>
            </div>
          )}
          {activeMeds
            .sort((a, b) => a.scheduled_time.localeCompare(b.scheduled_time))
            .map((med) => {
              const taken = takenToday.has(med.id);
              const overdue = isOverdue(med) && !taken;
              return (
                <button
                  key={med.id}
                  onClick={() => onSelectMed(med)}
                  className="organic-card w-full p-4 flex items-center gap-4 hover:shadow-md transition-shadow text-left animate-slide-up"
                >
                  <div className={`w-12 h-12 rounded-2xl ${colorMap[med.color] || colorMap.sage} border flex items-center justify-center flex-shrink-0`}>
                    <Pill className="w-6 h-6" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="font-semibold text-slate-800 dark:text-slate-100 truncate">{med.name}</p>
                      {taken && <CheckCircle2 className="w-4 h-4 text-sage-500 flex-shrink-0" />}
                    </div>
                    <p className="text-sm text-slate-400 dark:text-slate-500">
                      {med.dosage} • {formatTime(med.scheduled_time)} • {med.frequency.replace('-', ' ')}
                    </p>
                    {overdue && (
                      <p className="text-xs text-amber-600 dark:text-amber-400 font-medium mt-0.5">Overdue</p>
                    )}
                  </div>
                  {taken ? (
                    <span className="text-xs font-semibold text-sage-600 dark:text-sage-400 bg-sage-50 dark:bg-sage-900/30 px-2.5 py-1 rounded-full">Taken</span>
                  ) : (
                    <ChevronRight className="w-5 h-5 text-slate-300 dark:text-slate-600" />
                  )}
                </button>
              );
            })}
        </div>

        {/* Add medication FAB */}
        <button
          onClick={() => onNavigate('add')}
          className="fixed bottom-24 right-1/2 translate-x-[224px] w-14 h-14 rounded-full bg-sage-500 hover:bg-sage-600 text-white shadow-lg shadow-sage-500/30 flex items-center justify-center transition-all hover:scale-105 z-20"
        >
          <Plus className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
}

function CountdownUnit({ value, label }: { value: string; label: string }) {
  return (
    <div className="flex flex-col items-center">
      <span className="text-3xl font-bold text-white tabular-nums">{value}</span>
      <span className="text-[10px] uppercase text-slate-400 font-medium tracking-wide">{label}</span>
    </div>
  );
}
