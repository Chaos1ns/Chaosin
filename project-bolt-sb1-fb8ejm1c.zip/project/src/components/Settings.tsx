import { useState } from 'react';
import {
  ChevronLeft, Shield, Bell, Lock, Unlock, CheckCircle2, Pill,
  Sun, Moon, BellRing, Loader2,
} from 'lucide-react';
import type { Screen, FocusMode } from '@/types';
import { getSocialApps, updateSocialApp, getSettings, updateSettings } from '@/store';
import {
  notificationPermission, requestNotificationPermission, sendTestNotification,
  startReminderScheduler, stopReminderScheduler,
} from '@/notifications';
import { getMedications, isMedicationTakenToday } from '@/store';

interface Props {
  onNavigate: (screen: Screen) => void;
}

export default function Settings({ onNavigate }: Props) {
  const [settings, setSettings] = useState(getSettings());
  const [apps, setApps] = useState(getSocialApps());
  const [notifStatus, setNotifStatus] = useState<NotificationPermission | 'unsupported'>(notificationPermission());
  const [requestingNotif, setRequestingNotif] = useState(false);

  const toggleFocusMode = (mode: FocusMode) => {
    const updated = updateSettings({ focus_mode: mode });
    setSettings(updated);
  };

  const toggleApp = (id: string, current: boolean) => {
    updateSocialApp(id, !current);
    setApps(getSocialApps());
  };

  const toggleTheme = () => {
    const newTheme = settings.theme === 'dark' ? 'light' : 'dark';
    const updated = updateSettings({ theme: newTheme });
    setSettings(updated);
    if (newTheme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };

  const handleEnableNotifications = async () => {
    setRequestingNotif(true);
    const result = await requestNotificationPermission();
    setNotifStatus(result);
    setRequestingNotif(false);
    if (result === 'granted') {
      const updated = updateSettings({ notifications_enabled: true });
      setSettings(updated);
      startReminderScheduler(() => getMedications(), isMedicationTakenToday);
    }
  };

  const handleTestNotification = () => {
    sendTestNotification();
  };

  const isDark = settings.theme === 'dark';

  return (
    <div className="min-h-screen pb-32">
      <div className="blob bg-slate-300 w-72 h-72 -top-20 -right-20 dark:bg-slate-700" />
      <div className="blob bg-sage-300 w-64 h-64 top-40 -left-20 dark:bg-sage-900" />

      <div className="relative z-10 max-w-lg mx-auto px-5 pt-10">
        {/* Header */}
        <div className="flex items-center gap-3 mb-8">
          <button
            onClick={() => onNavigate('dashboard')}
            className="w-10 h-10 rounded-full bg-white dark:bg-slate-800 shadow-sm flex items-center justify-center hover:scale-105 transition-transform"
          >
            <ChevronLeft className="w-5 h-5 text-slate-500 dark:text-slate-400" />
          </button>
          <h1 className="text-2xl font-serif font-semibold text-slate-800 dark:text-slate-100">Settings</h1>
        </div>

        {/* Appearance — Dark Mode */}
        <h2 className="text-lg font-serif font-semibold text-slate-700 dark:text-slate-200 mb-3">Appearance</h2>
        <div className="organic-card p-5 mb-8 flex items-center gap-4">
          <div className={`w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0 ${
            isDark ? 'bg-slate-800' : 'bg-amber-100'
          }`}>
            {isDark ? <Moon className="w-6 h-6 text-amber-300" /> : <Sun className="w-6 h-6 text-amber-500" />}
          </div>
          <div className="flex-1">
            <p className="font-semibold text-slate-800 dark:text-slate-100">Dark Mode</p>
            <p className="text-sm text-slate-400 dark:text-slate-500">
              {isDark ? 'Easy on the eyes at night' : 'Switch to a dark theme'}
            </p>
          </div>
          <Toggle on={isDark} onClick={toggleTheme} />
        </div>

        {/* Notifications */}
        <h2 className="text-lg font-serif font-semibold text-slate-700 dark:text-slate-200 mb-3">Notifications</h2>
        <div className="organic-card p-5 mb-8">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-12 h-12 rounded-2xl bg-sage-100 dark:bg-sage-900/40 flex items-center justify-center flex-shrink-0">
              <BellRing className="w-6 h-6 text-sage-600 dark:text-sage-400" />
            </div>
            <div className="flex-1">
              <p className="font-semibold text-slate-800 dark:text-slate-100">Push Reminders</p>
              <p className="text-sm text-slate-400 dark:text-slate-500">
                {notifStatus === 'granted'
                  ? 'Reminders are active. You will be notified at pill time.'
                  : notifStatus === 'denied'
                  ? 'Permission denied. Enable in browser settings to get reminders.'
                  : notifStatus === 'unsupported'
                  ? 'Notifications not supported on this device.'
                  : 'Get browser notifications when it is time to take your pill.'}
              </p>
            </div>
          </div>
          {notifStatus === 'granted' ? (
            <button
              onClick={handleTestNotification}
              className="w-full px-5 py-3 rounded-2xl bg-sage-500 text-white font-semibold hover:bg-sage-600 transition-colors flex items-center justify-center gap-2"
            >
              <BellRing className="w-5 h-5" /> Send Test Notification
            </button>
          ) : notifStatus !== 'unsupported' && notifStatus !== 'denied' ? (
            <button
              onClick={handleEnableNotifications}
              disabled={requestingNotif}
              className="w-full px-5 py-3 rounded-2xl bg-sage-500 text-white font-semibold hover:bg-sage-600 transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {requestingNotif ? (
                <><Loader2 className="w-5 h-5 animate-spin" /> Requesting permission...</>
              ) : (
                <><Bell className="w-5 h-5" /> Enable Notifications</>
              )}
            </button>
          ) : notifStatus === 'denied' ? (
            <p className="text-xs text-slate-400 dark:text-slate-500 text-center">
              Please reset notification permissions in your browser settings.
            </p>
          ) : null}
        </div>

        {/* Focus Mode */}
        <h2 className="text-lg font-serif font-semibold text-slate-700 dark:text-slate-200 mb-3">Focus Mode</h2>
        <div className="grid grid-cols-2 gap-3 mb-8">
          <button
            onClick={() => toggleFocusMode('strict')}
            className={`organic-card p-5 text-left transition-all ${
              settings.focus_mode === 'strict' ? 'ring-2 ring-sage-500 bg-sage-50 dark:bg-sage-900/20' : ''
            }`}
          >
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-3 ${
              settings.focus_mode === 'strict' ? 'bg-sage-500' : 'bg-slate-100 dark:bg-slate-700'
            }`}>
              <Lock className={`w-5 h-5 ${settings.focus_mode === 'strict' ? 'text-white' : 'text-slate-500 dark:text-slate-400'}`} />
            </div>
            <p className="font-semibold text-slate-800 dark:text-slate-100 mb-1">Strict Mode</p>
            <p className="text-xs text-slate-400 dark:text-slate-500 leading-relaxed">
              Blocks selected social apps until your pill is verified.
            </p>
            {settings.focus_mode === 'strict' && (
              <div className="flex items-center gap-1 mt-2">
                <CheckCircle2 className="w-4 h-4 text-sage-500" />
                <span className="text-xs font-medium text-sage-600 dark:text-sage-400">Active</span>
              </div>
            )}
          </button>

          <button
            onClick={() => toggleFocusMode('notification')}
            className={`organic-card p-5 text-left transition-all ${
              settings.focus_mode === 'notification' ? 'ring-2 ring-amber-400 bg-amber-50 dark:bg-amber-900/20' : ''
            }`}
          >
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-3 ${
              settings.focus_mode === 'notification' ? 'bg-amber-400' : 'bg-slate-100 dark:bg-slate-700'
            }`}>
              <Bell className={`w-5 h-5 ${settings.focus_mode === 'notification' ? 'text-white' : 'text-slate-500 dark:text-slate-400'}`} />
            </div>
            <p className="font-semibold text-slate-800 dark:text-slate-100 mb-1">Notification Only</p>
            <p className="text-xs text-slate-400 dark:text-slate-500 leading-relaxed">
              Gentle reminders without blocking any apps.
            </p>
            {settings.focus_mode === 'notification' && (
              <div className="flex items-center gap-1 mt-2">
                <CheckCircle2 className="w-4 h-4 text-amber-500" />
                <span className="text-xs font-medium text-amber-600 dark:text-amber-400">Active</span>
              </div>
            )}
          </button>
        </div>

        {/* App Blocking */}
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-serif font-semibold text-slate-700 dark:text-slate-200">App Blocking</h2>
          {settings.focus_mode === 'notification' && (
            <span className="text-xs text-amber-600 dark:text-amber-400 font-medium flex items-center gap-1">
              <Bell className="w-3.5 h-3.5" /> Disabled in Notification mode
            </span>
          )}
        </div>

        <p className="text-sm text-slate-400 dark:text-slate-500 mb-4">
          {settings.focus_mode === 'strict'
            ? 'Toggle which apps are locked until you verify your daily pill intake.'
            : 'Switch to Strict Mode to enable app blocking.'}
        </p>

        <div className="space-y-2 mb-8">
          {apps.map((app) => {
            const isLocked = settings.focus_mode === 'strict' && app.is_monitored;
            return (
              <div
                key={app.id}
                className={`organic-card p-4 flex items-center gap-4 transition-opacity ${
                  settings.focus_mode === 'notification' ? 'opacity-60' : ''
                }`}
              >
                <div
                  className="w-11 h-11 rounded-2xl flex items-center justify-center flex-shrink-0"
                  style={{ backgroundColor: app.color }}
                >
                  <Pill className="w-5 h-5 text-white/80" />
                </div>
                <div className="flex-1">
                  <p className="font-semibold text-slate-800 dark:text-slate-100">{app.name}</p>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    {isLocked ? (
                      <>
                        <Lock className="w-3.5 h-3.5 text-slate-400" />
                        <span className="text-xs text-slate-400 dark:text-slate-500">Locked until pill verified</span>
                      </>
                    ) : app.is_monitored && settings.focus_mode === 'strict' ? (
                      <>
                        <Unlock className="w-3.5 h-3.5 text-sage-500" />
                        <span className="text-xs text-sage-600 dark:text-sage-400">Unlocked</span>
                      </>
                    ) : (
                      <>
                        <Unlock className="w-3.5 h-3.5 text-slate-400" />
                        <span className="text-xs text-slate-400 dark:text-slate-500">Not monitored</span>
                      </>
                    )}
                  </div>
                </div>
                <Toggle
                  on={app.is_monitored}
                  disabled={settings.focus_mode === 'notification'}
                  onClick={() => toggleApp(app.id, app.is_monitored)}
                />
              </div>
            );
          })}
        </div>

        {/* About */}
        <div className="organic-card p-5 mb-6">
          <div className="flex items-center gap-2 mb-3">
            <Shield className="w-5 h-5 text-sage-500" />
            <h3 className="font-semibold text-slate-700 dark:text-slate-200">About Ritual</h3>
          </div>
          <p className="text-sm text-slate-400 dark:text-slate-500 leading-relaxed">
            Ritual helps you build a mindful medication routine. Verify your pills with on-device AI photo
            checks, stay on schedule with push notifications and countdown alerts, and use app blocking to
            create healthy accountability around your daily intake.
          </p>
        </div>
      </div>
    </div>
  );
}

function Toggle({
  on,
  disabled,
  onClick,
}: {
  on: boolean;
  disabled?: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`relative w-12 h-7 rounded-full transition-colors flex-shrink-0 ${
        on ? 'bg-sage-500' : 'bg-slate-200 dark:bg-slate-700'
      } ${disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}`}
    >
      <span
        className={`absolute top-1 left-1 w-5 h-5 rounded-full bg-white shadow-sm transition-transform ${
          on ? 'translate-x-5' : ''
        }`}
      />
    </button>
  );
}
