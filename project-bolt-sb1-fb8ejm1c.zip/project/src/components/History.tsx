import { useState, useMemo } from 'react';
import { Calendar, CheckCircle2, Pill, Flame, ChevronLeft } from 'lucide-react';
import type { Screen } from '@/types';
import { getIntakeLogs, getSettings } from '@/store';
import { formatDateTime, formatDate } from '@/utils';

interface Props {
  onNavigate: (screen: Screen) => void;
}

export default function History({ onNavigate }: Props) {
  const [logs] = useState(getIntakeLogs());
  const settings = getSettings();

  const grouped = useMemo(() => {
    const map = new Map<string, typeof logs>();
    for (const log of logs) {
      const dateKey = new Date(log.taken_at).toDateString();
      if (!map.has(dateKey)) map.set(dateKey, []);
      map.get(dateKey)!.push(log);
    }
    return Array.from(map.entries()).slice(0, 14);
  }, [logs]);

  const todayStr = new Date().toDateString();
  const todayCount = logs.filter((l) => new Date(l.taken_at).toDateString() === todayStr).length;
  const weekAgo = Date.now() - 7 * 86400000;
  const weekCount = logs.filter((l) => new Date(l.taken_at).getTime() >= weekAgo).length;

  return (
    <div className="min-h-screen pb-32">
      <div className="blob bg-amber-200 w-72 h-72 -top-20 -right-20 dark:bg-amber-900" />
      <div className="blob bg-sage-300 w-64 h-64 top-40 -left-20 dark:bg-sage-800" />

      <div className="relative z-10 max-w-lg mx-auto px-5 pt-10">
        {/* Header */}
        <div className="flex items-center gap-3 mb-8">
          <button
            onClick={() => onNavigate('dashboard')}
            className="w-10 h-10 rounded-full bg-white dark:bg-slate-800 shadow-sm flex items-center justify-center hover:scale-105 transition-transform"
          >
            <ChevronLeft className="w-5 h-5 text-slate-500 dark:text-slate-400" />
          </button>
          <h1 className="text-2xl font-serif font-semibold text-slate-800 dark:text-slate-100">History</h1>
        </div>

        {/* Stats cards */}
        <div className="grid grid-cols-3 gap-3 mb-8">
          <div className="organic-card p-4 text-center">
            <div className="w-10 h-10 rounded-full bg-amber-100 dark:bg-amber-900/30 flex items-center justify-center mx-auto mb-2">
              <Flame className="w-5 h-5 text-amber-600 dark:text-amber-400" />
            </div>
            <p className="text-2xl font-bold text-slate-800 dark:text-slate-100">{settings.streak_count}</p>
            <p className="text-xs text-slate-400 dark:text-slate-500">Day Streak</p>
          </div>
          <div className="organic-card p-4 text-center">
            <div className="w-10 h-10 rounded-full bg-sage-100 dark:bg-sage-900/40 flex items-center justify-center mx-auto mb-2">
              <CheckCircle2 className="w-5 h-5 text-sage-600 dark:text-sage-400" />
            </div>
            <p className="text-2xl font-bold text-slate-800 dark:text-slate-100">{todayCount}</p>
            <p className="text-xs text-slate-400 dark:text-slate-500">Today</p>
          </div>
          <div className="organic-card p-4 text-center">
            <div className="w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-700 flex items-center justify-center mx-auto mb-2">
              <Calendar className="w-5 h-5 text-slate-600 dark:text-slate-300" />
            </div>
            <p className="text-2xl font-bold text-slate-800 dark:text-slate-100">{weekCount}</p>
            <p className="text-xs text-slate-400 dark:text-slate-500">This Week</p>
          </div>
        </div>

        {/* Log entries */}
        <h2 className="text-lg font-serif font-semibold text-slate-700 dark:text-slate-200 mb-3">Recent Intakes</h2>
        {logs.length === 0 ? (
          <div className="organic-card p-8 text-center">
            <Pill className="w-10 h-10 text-slate-300 dark:text-slate-600 mx-auto mb-3" />
            <p className="text-slate-400 dark:text-slate-500 text-sm">No intake history yet.</p>
            <p className="text-slate-300 dark:text-slate-600 text-xs mt-1">Your verified intakes will appear here.</p>
          </div>
        ) : (
          <div className="space-y-5">
            {grouped.map(([dateStr, dayLogs]) => (
              <div key={dateStr}>
                <p className="text-xs font-semibold text-slate-400 dark:text-slate-500 uppercase tracking-wide mb-2">
                  {new Date(dateStr).toDateString() === todayStr ? 'Today' : formatDate(dayLogs[0].taken_at)}
                </p>
                <div className="space-y-2">
                  {dayLogs.map((log) => (
                    <div key={log.id} className="organic-card p-4 flex items-center gap-3 animate-slide-up">
                      <div className="w-10 h-10 rounded-xl bg-sage-100 dark:bg-sage-900/40 flex items-center justify-center flex-shrink-0">
                        <Pill className="w-5 h-5 text-sage-600 dark:text-sage-400" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="font-semibold text-slate-800 dark:text-slate-100 truncate">{log.medication_name}</p>
                          {log.photo_verified && (
                            <span className="text-[10px] font-semibold text-sage-600 dark:text-sage-400 bg-sage-50 dark:bg-sage-900/30 px-2 py-0.5 rounded-full flex items-center gap-0.5 flex-shrink-0">
                              <CheckCircle2 className="w-3 h-3" /> Verified
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-400 dark:text-slate-500">
                          {log.dosage} • {formatDateTime(log.taken_at)}
                        </p>
                      </div>
                      <CheckCircle2 className="w-5 h-5 text-sage-400 flex-shrink-0" />
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
