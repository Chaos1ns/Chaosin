import { useState, useRef, useEffect, useCallback } from 'react';
import {
  Camera, Upload, CheckCircle2, X, ScanLine, Sparkles, ChevronRight,
  AlertCircle, Pill, Unlock, Loader2, Brain, RefreshCw,
} from 'lucide-react';
import type { Medication, Screen } from '@/types';
import { recordIntake, getSettings, getSocialApps } from '@/store';
import { formatTime } from '@/utils';
import { analyzeImage, loadDetectionModel, type DetectionResult } from '@/ai-detection';

interface Props {
  medication: Medication;
  onNavigate: (screen: Screen) => void;
}

type Phase = 'upload' | 'loading-model' | 'analyzing' | 'result' | 'success' | 'failed';

export default function VerifyScreen({ medication, onNavigate }: Props) {
  const [phase, setPhase] = useState<Phase>('upload');
  const [photoUrl, setPhotoUrl] = useState<string | null>(null);
  const [scanProgress, setScanProgress] = useState(0);
  const [scanStep, setScanStep] = useState(0);
  const [detection, setDetection] = useState<DetectionResult | null>(null);
  const [modelStatus, setModelStatus] = useState<'idle' | 'loading' | 'ready'>('idle');
  const fileRef = useRef<HTMLInputElement>(null);
  const cameraRef = useRef<HTMLInputElement>(null);
  const imgRef = useRef<HTMLImageElement>(null);

  const scanSteps = [
    'Loading AI model...',
    'Processing image with neural network...',
    'Detecting objects in frame...',
    'Verifying pill context...',
  ];

  // Preload model when photo is selected
  useEffect(() => {
    if (!photoUrl || modelStatus !== 'idle') return;
    setModelStatus('loading');
    loadDetectionModel()
      .then(() => setModelStatus('ready'))
      .catch(() => {
        setModelStatus('idle');
        setPhase('failed');
        setDetection({ verified: false, detections: [], reason: 'Failed to load AI model. Please check your connection.' });
      });
  }, [photoUrl, modelStatus]);

  const runAnalysis = useCallback(async () => {
    if (!imgRef.current) return;
    setPhase('analyzing');
    setScanProgress(0);
    setScanStep(0);

    // Animate steps while model runs
    setScanStep(0);
    const stepTimer = setInterval(() => {
      setScanStep((s) => Math.min(s + 1, scanSteps.length - 1));
    }, 600);
    const progressTimer = setInterval(() => {
      setScanProgress((p) => Math.min(p + 3, 90));
    }, 50);

    try {
      // Ensure model is loaded
      await loadDetectionModel();
      setScanStep(2);
      setScanProgress(95);

      const result = await analyzeImage(imgRef.current);
      setScanProgress(100);
      setScanStep(3);
      setDetection(result);

      clearInterval(stepTimer);
      clearInterval(progressTimer);

      setTimeout(() => {
        if (result.verified) {
          setPhase('success');
          recordIntake(medication.id);
        } else {
          setPhase('failed');
        }
      }, 600);
    } catch {
      clearInterval(stepTimer);
      clearInterval(progressTimer);
      setDetection({ verified: false, detections: [], reason: 'Analysis failed. Please try again.' });
      setPhase('failed');
    }
  }, [medication.id]);

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (ev) => {
        setPhotoUrl(ev.target?.result as string);
        setPhase('upload');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleStartScan = () => {
    if (photoUrl) runAnalysis();
  };

  return (
    <div className="min-h-screen pb-32">
      <div className="blob bg-sage-300 w-72 h-72 -top-20 -right-20 dark:bg-sage-700" />
      <div className="blob bg-amber-200 w-64 h-64 top-60 -left-20 dark:bg-amber-800" />

      <div className="relative z-10 max-w-lg mx-auto px-5 pt-10">
        {/* Back */}
        <button
          onClick={() => onNavigate('dashboard')}
          className="mb-6 flex items-center gap-1.5 text-sm text-slate-500 dark:text-slate-400 font-medium hover:text-slate-700 dark:hover:text-slate-200"
        >
          <X className="w-4 h-4" /> Cancel
        </button>

        {/* Medication info */}
        <div className="organic-card p-5 mb-6 animate-fade-in">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-sage-100 dark:bg-sage-900/40 flex items-center justify-center">
              <Pill className="w-6 h-6 text-sage-600 dark:text-sage-400" />
            </div>
            <div>
              <p className="font-semibold text-slate-800 dark:text-slate-100 text-lg">{medication.name}</p>
              <p className="text-sm text-slate-400 dark:text-slate-500">{medication.dosage} • Scheduled at {formatTime(medication.scheduled_time)}</p>
            </div>
          </div>
        </div>

        {/* Upload phase */}
        {phase === 'upload' && (
          <div className="animate-slide-up">
            <h2 className="text-xl font-serif font-semibold text-slate-700 dark:text-slate-200 mb-2">Verify Your Pill</h2>
            <p className="text-sm text-slate-400 dark:text-slate-500 mb-6">
              Take a photo of your pill. Our on-device AI will verify it before logging your intake.
            </p>

            {!photoUrl ? (
              <div className="organic-card border-2 border-dashed border-slate-200 dark:border-slate-700 p-8 text-center">
                <div className="w-16 h-16 rounded-full bg-sage-50 dark:bg-sage-900/30 flex items-center justify-center mx-auto mb-4">
                  <Camera className="w-8 h-8 text-sage-500 dark:text-sage-400" />
                </div>
                <p className="font-medium text-slate-700 dark:text-slate-200 mb-1">Capture or upload a photo</p>
                <p className="text-sm text-slate-400 dark:text-slate-500 mb-6">Position the pill clearly in the frame</p>
                <div className="flex flex-col gap-3">
                  <button
                    onClick={() => cameraRef.current?.click()}
                    className="flex items-center justify-center gap-2 px-5 py-3 rounded-2xl bg-sage-500 text-white font-semibold hover:bg-sage-600 transition-colors"
                  >
                    <Camera className="w-5 h-5" /> Take Photo
                  </button>
                  <button
                    onClick={() => fileRef.current?.click()}
                    className="flex items-center justify-center gap-2 px-5 py-3 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-semibold hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                  >
                    <Upload className="w-5 h-5" /> Upload from Gallery
                  </button>
                </div>
                <input ref={cameraRef} type="file" accept="image/*" capture="environment" onChange={handleFile} className="hidden" />
                <input ref={fileRef} type="file" accept="image/*" onChange={handleFile} className="hidden" />
              </div>
            ) : (
              <div className="organic-card overflow-hidden animate-scale-in">
                <img src={photoUrl} alt="Pill" className="w-full h-64 object-cover" ref={imgRef} onLoad={() => { /* trigger model preload via photoUrl effect */ }} />
                {/* Hidden img for analysis when not displayed yet */}
                {!photoUrl && <img src={photoUrl} alt="" ref={imgRef} className="hidden" />}
                <div className="p-4">
                  <div className="flex items-center gap-2 mb-4">
                    {modelStatus === 'loading' ? (
                      <>
                        <Loader2 className="w-5 h-5 text-sage-500 animate-spin" />
                        <p className="text-sm font-medium text-slate-600 dark:text-slate-300">Loading AI model...</p>
                      </>
                    ) : modelStatus === 'ready' ? (
                      <>
                        <CheckCircle2 className="w-5 h-5 text-sage-500" />
                        <p className="text-sm font-medium text-slate-600 dark:text-slate-300">Photo captured — AI ready</p>
                      </>
                    ) : (
                      <>
                        <CheckCircle2 className="w-5 h-5 text-sage-500" />
                        <p className="text-sm font-medium text-slate-600 dark:text-slate-300">Photo captured</p>
                      </>
                    )}
                  </div>
                  <div className="flex gap-3">
                    <button
                      onClick={() => { setPhotoUrl(null); setModelStatus('idle'); setDetection(null); }}
                      className="flex-1 px-4 py-3 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-semibold hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                    >
                      Retake
                    </button>
                    <button
                      onClick={handleStartScan}
                      disabled={modelStatus === 'loading'}
                      className="flex-1 px-4 py-3 rounded-2xl bg-sage-500 text-white font-semibold hover:bg-sage-600 transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
                    >
                      <ScanLine className="w-5 h-5" /> {modelStatus === 'loading' ? 'Loading...' : 'Analyze with AI'}
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Analyzing phase */}
        {(phase === 'analyzing' || phase === 'loading-model') && (
          <div className="animate-fade-in">
            <div className="organic-card overflow-hidden mb-6 relative">
              {photoUrl && (
                <div className="relative">
                  <img src={photoUrl} alt="Pill" className="w-full h-72 object-cover" />
                  <div className="absolute inset-0 overflow-hidden">
                    <div
                      className="absolute left-0 right-0 h-1 bg-sage-400 shadow-[0_0_20px_rgba(93,133,80,0.8)] transition-all duration-75"
                      style={{ top: `${scanProgress * 0.72}%` }}
                    />
                  </div>
                  <div className="absolute inset-0 border-2 border-sage-400/30" />
                  <div className="absolute top-3 left-3 w-6 h-6 border-t-2 border-l-2 border-sage-400 rounded-tl-lg" />
                  <div className="absolute top-3 right-3 w-6 h-6 border-t-2 border-r-2 border-sage-400 rounded-tr-lg" />
                  <div className="absolute bottom-3 left-3 w-6 h-6 border-b-2 border-l-2 border-sage-400 rounded-bl-lg" />
                  <div className="absolute bottom-3 right-3 w-6 h-6 border-b-2 border-r-2 border-sage-400 rounded-br-lg" />
                </div>
              )}
              <div className="p-5">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Brain className="w-5 h-5 text-sage-500 animate-pulse-soft" />
                    <p className="font-semibold text-slate-700 dark:text-slate-200">Neural Network Analysis</p>
                  </div>
                  <span className="text-sm font-bold text-sage-600 dark:text-sage-400 tabular-nums">{scanProgress}%</span>
                </div>
                <div className="h-2 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden mb-4">
                  <div
                    className="h-full bg-gradient-to-r from-sage-400 to-sage-500 rounded-full transition-all duration-75"
                    style={{ width: `${scanProgress}%` }}
                  />
                </div>
                <div className="space-y-2">
                  {scanSteps.map((step, i) => (
                    <div key={i} className="flex items-center gap-2">
                      {i < scanStep ? (
                        <CheckCircle2 className="w-4 h-4 text-sage-500 flex-shrink-0" />
                      ) : i === scanStep ? (
                        <div className="w-4 h-4 rounded-full border-2 border-slate-300 dark:border-slate-600 border-t-sage-500 animate-spin flex-shrink-0" />
                      ) : (
                        <div className="w-4 h-4 rounded-full border-2 border-slate-200 dark:border-slate-700 flex-shrink-0" />
                      )}
                      <p className={`text-sm ${i <= scanStep ? 'text-slate-600 dark:text-slate-300' : 'text-slate-300 dark:text-slate-600'}`}>{step}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Failed phase */}
        {phase === 'failed' && detection && (
          <div className="animate-scale-in text-center pt-8">
            <div className="relative inline-block mb-6">
              <div className="absolute inset-0 bg-rose-400 rounded-full blur-2xl opacity-30" />
              <div className="relative w-24 h-24 rounded-full bg-rose-500 flex items-center justify-center">
                <X className="w-14 h-14 text-white" />
              </div>
            </div>
            <h2 className="text-2xl font-serif font-semibold text-slate-800 dark:text-slate-100 mb-2">Verification Failed</h2>
            <p className="text-slate-400 dark:text-slate-500 mb-6 max-w-sm mx-auto">{detection.reason}</p>
            {detection.detections.length > 0 && (
              <div className="organic-card p-4 mb-6 text-left">
                <p className="text-xs font-semibold text-slate-400 dark:text-slate-500 mb-2">Detected objects:</p>
                <div className="flex flex-wrap gap-2">
                  {detection.detections.map((d, i) => (
                    <span key={i} className="text-xs font-medium text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-700 px-2.5 py-1 rounded-full">
                      {d.class} ({Math.round(d.score * 100)}%)
                    </span>
                  ))}
                </div>
              </div>
            )}
            <button
              onClick={() => { setPhotoUrl(null); setDetection(null); setPhase('upload'); setModelStatus('idle'); }}
              className="px-6 py-3.5 rounded-2xl bg-sage-500 text-white font-semibold hover:bg-sage-600 transition-colors flex items-center justify-center gap-2 mx-auto"
            >
              <RefreshCw className="w-5 h-5" /> Try Again
            </button>
          </div>
        )}

        {/* Success phase */}
        {phase === 'success' && (
          <div className="animate-scale-in text-center pt-8">
            <div className="relative inline-block mb-6">
              <div className="absolute inset-0 bg-sage-400 rounded-full blur-2xl opacity-30 animate-pulse-soft" />
              <div className="relative w-24 h-24 rounded-full bg-sage-500 flex items-center justify-center">
                <CheckCircle2 className="w-14 h-14 text-white" />
              </div>
            </div>
            <h2 className="text-2xl font-serif font-semibold text-slate-800 dark:text-slate-100 mb-2">Pill Verified Successfully!</h2>
            <p className="text-slate-400 dark:text-slate-500 mb-1">
              <span className="font-semibold text-slate-600 dark:text-slate-300">{medication.name}</span> ({medication.dosage}) confirmed by AI.
            </p>
            <p className="text-slate-400 dark:text-slate-500 mb-4">Your intake has been logged.</p>

            {detection && detection.detections.length > 0 && (
              <div className="organic-card p-4 mb-6 text-left">
                <div className="flex items-center gap-2 mb-2">
                  <Sparkles className="w-4 h-4 text-sage-500" />
                  <p className="text-xs font-semibold text-slate-400 dark:text-slate-500">AI detected:</p>
                </div>
                <div className="flex flex-wrap gap-2">
                  {detection.detections.map((d, i) => (
                    <span key={i} className="text-xs font-medium text-sage-600 dark:text-sage-400 bg-sage-50 dark:bg-sage-900/30 px-2.5 py-1 rounded-full">
                      {d.class} ({Math.round(d.score * 100)}%)
                    </span>
                  ))}
                </div>
              </div>
            )}

            <UnlockedApps />

            <button
              onClick={() => onNavigate('dashboard')}
              className="w-full px-5 py-3.5 rounded-2xl bg-sage-500 text-white font-semibold hover:bg-sage-600 transition-colors flex items-center justify-center gap-2"
            >
              <Unlock className="w-5 h-5" /> Done
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

function UnlockedApps() {
  const settings = getSettings();
  const apps = getSocialApps().filter((a) => a.is_monitored);

  if (settings.focus_mode === 'notification') {
    return (
      <div className="organic-card p-4 mb-6 flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-amber-100 dark:bg-amber-900/30 flex items-center justify-center">
          <AlertCircle className="w-5 h-5 text-amber-600 dark:text-amber-400" />
        </div>
        <p className="text-sm text-slate-500 dark:text-slate-400 text-left">
          Notification mode is on — apps remain accessible. Switch to Strict Mode in Settings to enable app blocking.
        </p>
      </div>
    );
  }

  return (
    <div className="organic-card p-5 mb-6">
      <div className="flex items-center gap-2 mb-4">
        <Unlock className="w-5 h-5 text-sage-500" />
        <p className="font-semibold text-slate-700 dark:text-slate-200">Apps Unlocked</p>
      </div>
      <div className="flex justify-center gap-4">
        {apps.slice(0, 4).map((app) => (
          <div key={app.id} className="flex flex-col items-center gap-1">
            <div
              className="w-12 h-12 rounded-2xl flex items-center justify-center opacity-100 transition-opacity"
              style={{ backgroundColor: app.color }}
            >
              <ChevronRight className="w-5 h-5 text-white/80" />
            </div>
            <span className="text-[10px] text-slate-400 dark:text-slate-500">{app.name.split(' ')[0]}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
