import type { Medication } from '@/types';
import { getSettings, updateSettings } from '@/store';

// --- Theme ---

export function applyTheme(theme: 'light' | 'dark'): void {
  if (theme === 'dark') {
    document.documentElement.classList.add('dark');
  } else {
    document.documentElement.classList.remove('dark');
  }
}

export function initTheme(): void {
  const settings = getSettings();
  applyTheme(settings.theme);
}

export function toggleTheme(): 'light' | 'dark' {
  const current = getSettings().theme;
  const next = current === 'dark' ? 'light' : 'dark';
  applyTheme(next);
  updateSettings({ theme: next });
  return next;
}

// --- Notifications ---

export function notificationPermission(): NotificationPermission | 'unsupported' {
  if (typeof Notification === 'undefined') return 'unsupported';
  return Notification.permission;
}

export async function requestNotificationPermission(): Promise<NotificationPermission | 'unsupported'> {
  if (typeof Notification === 'undefined') return 'unsupported';
  if (Notification.permission === 'granted') return 'granted';
  const result = await Notification.requestPermission();
  return result;
}

export function sendNotification(title: string, body: string): void {
  if (typeof Notification === 'undefined') return;
  if (Notification.permission !== 'granted') return;
  new Notification(title, {
    body,
    icon: '/vite.svg',
    badge: '/vite.svg',
  });
}

export function sendTestNotification(): void {
  sendNotification('Ritual — Test Notification', 'Notifications are working! You will be reminded when it is time to take your medication.');
}

export function sendPillReminder(med: Medication): void {
  sendNotification(
    `Time to take ${med.name}`,
    `Your ${med.dosage} dose of ${med.name} is scheduled now. Open Ritual to verify and log your intake.`,
  );
}

// --- Reminder scheduling ---

let reminderInterval: ReturnType<typeof setInterval> | null = null;

export function startReminderScheduler(getMeds: () => Medication[], isTaken: (id: string) => boolean): void {
  stopReminderScheduler();
  reminderInterval = setInterval(() => {
    const now = new Date();
    const nowMin = now.getHours() * 60 + now.getMinutes();
    const meds = getMeds().filter((m) => m.active);

    for (const med of meds) {
      if (isTaken(med.id)) continue;
      const [h, m] = med.scheduled_time.split(':').map(Number);
      const medMin = h * 60 + m;

      // Send reminder if within 1 minute of scheduled time (and not past 10 min)
      const diff = nowMin - medMin;
      if (diff >= 0 && diff <= 1) {
        sendPillReminder(med);
      }
    }
  }, 60000); // check every minute
}

export function stopReminderScheduler(): void {
  if (reminderInterval) {
    clearInterval(reminderInterval);
    reminderInterval = null;
  }
}
