export type Frequency = 'daily' | 'twice-daily' | 'three-times-daily' | 'weekly' | 'as-needed';

export type MedicationColor = 'sage' | 'amber' | 'slate' | 'rose' | 'sky';

export interface Medication {
  id: string;
  name: string;
  dosage: string;
  scheduled_time: string; // HH:MM
  frequency: Frequency;
  notes?: string;
  color: MedicationColor;
  active: boolean;
  created_at: string;
}

export type IntakeStatus = 'taken' | 'missed';

export interface IntakeLog {
  id: string;
  medication_id: string;
  medication_name: string;
  dosage: string;
  taken_at: string;
  photo_verified: boolean;
  verification_result: 'verified' | 'failed' | null;
  status: IntakeStatus;
  created_at: string;
}

export type FocusMode = 'strict' | 'notification';

export type AppLockState = 'locked' | 'unlocked';

export interface SocialApp {
  id: string;
  name: string;
  icon_key: string;
  color: string;
  is_monitored: boolean;
}

export interface AppSettings {
  focus_mode: FocusMode;
  streak_count: number;
  last_intake_date: string | null; // YYYY-MM-DD
  theme: 'light' | 'dark';
  notifications_enabled: boolean;
}

export type Screen = 'dashboard' | 'verify' | 'history' | 'settings';
