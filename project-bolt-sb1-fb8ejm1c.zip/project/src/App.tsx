import { useState, useEffect } from 'react';
import type { Screen, Medication } from '@/types';
import { initStore, getMedications, isMedicationTakenToday } from '@/store';
import { initTheme, startReminderScheduler, notificationPermission } from '@/notifications';
import Dashboard from '@/components/Dashboard';
import VerifyScreen from '@/components/VerifyScreen';
import History from '@/components/History';
import Settings from '@/components/Settings';
import AddMedicationModal from '@/components/AddMedicationModal';
import BottomNav from '@/components/BottomNav';

export default function App() {
  const [screen, setScreen] = useState<Screen>('dashboard');
  const [selectedMed, setSelectedMed] = useState<Medication | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingMed, setEditingMed] = useState<Medication | null>(null);
  const [refreshKey, setRefreshKey] = useState(0);

  useEffect(() => {
    initStore();
    initTheme();

    // Start reminder scheduler if notifications are already granted
    if (notificationPermission() === 'granted') {
      startReminderScheduler(() => getMedications(), isMedicationTakenToday);
    }

    return () => {
      // scheduler cleanup handled by the singleton in notifications.ts
    };
  }, []);

  const handleNavigate = (s: Screen | 'add') => {
    if (s === 'add') {
      setEditingMed(null);
      setShowAddModal(true);
    } else {
      setScreen(s);
    }
  };

  const handleSelectMed = (med: Medication) => {
    setSelectedMed(med);
    setScreen('verify');
  };

  const handleVerifyNavigate = (s: Screen) => {
    setScreen(s);
    setSelectedMed(null);
    setRefreshKey((k) => k + 1);
  };

  const verifyMed = selectedMed ?? getMedications().find((m) => m.active) ?? null;

  return (
    <div className="min-h-screen bg-sage-50 dark:bg-slate-950 transition-colors duration-400">
      {screen === 'dashboard' && (
        <Dashboard
          key={`dash-${refreshKey}`}
          onNavigate={handleNavigate}
          onSelectMed={handleSelectMed}
        />
      )}

      {screen === 'verify' && verifyMed && (
        <VerifyScreen medication={verifyMed} onNavigate={handleVerifyNavigate} />
      )}

      {screen === 'verify' && !verifyMed && (
        <div className="min-h-screen flex items-center justify-center">
          <p className="text-slate-400 dark:text-slate-500">Add a medication first to use verification.</p>
        </div>
      )}

      {screen === 'history' && <History key={`hist-${refreshKey}`} onNavigate={setScreen} />}

      {screen === 'settings' && <Settings onNavigate={setScreen} />}

      {showAddModal && (
        <AddMedicationModal
          medication={editingMed}
          onClose={() => setShowAddModal(false)}
          onSaved={() => {
            setShowAddModal(false);
            setRefreshKey((k) => k + 1);
            setScreen('dashboard');
          }}
        />
      )}

      <BottomNav current={screen} onNavigate={handleNavigate} />
    </div>
  );
}
