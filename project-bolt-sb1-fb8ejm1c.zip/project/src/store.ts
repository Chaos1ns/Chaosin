import type { Medication, IntakeLog, SocialApp, AppSettings, Frequency, MedicationColor } from '@/types';

const KEYS = {
  meds: 'ritual_medications',
  logs: 'ritual_intake_logs',
  apps: 'ritual_social_apps',
  settings: 'ritual_settings',
};

function read<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function write<T>(key: string, value: T): void {
  localStorage.setItem(key, JSON.stringify(value));
}

function uid(): string {
  return crypto.randomUUID();
}

// --- Defaults ---

const DEFAULT_MEDICATIONS: Medication[] = [
  {
    id: uid(),
    name: 'Vitamin D3',
    dosage: '1000 IU',
    scheduled_time: '08:00',
    frequency: 'daily',
    notes: 'Take with breakfast',
    color: 'amber',
    active: true,
    created_at: new Date().toISOString(),
  },
  {
    id: uid(),
    name: 'Omega-3',
    dosage: '500mg',
    scheduled_time: '12:30',
    frequency: 'twice-daily',
    notes: 'With lunch',
    color: 'sage',
    active: true,
    created_at: new Date().toISOString(),
  },
  {
    id: uid(),
    name: 'Magnesium',
    dosage: '200mg',
    scheduled_time: '21:00',
    frequency: 'daily',
    notes: 'Before bed for better sleep',
    color: 'slate',
    active: true,
    created_at: new Date().toISOString(),
  },
];

const DEFAULT_APPS: SocialApp[] = [
  { id: uid(), name: 'Instagram', icon_key: 'instagram', color: '#E1306C', is_monitored: true },
  { id: uid(), name: 'TikTok', icon_key: 'music', color: '#010101', is_monitored: true },
  { id: uid(), name: 'X (Twitter)', icon_key: 'twitter', color: '#010101', is_monitored: true },
  { id: uid(), name: 'YouTube', icon_key: 'youtube', color: '#FF0000', is_monitored: true },
  { id: uid(), name: 'Snapchat', icon_key: 'ghost', color: '#FFFC00', is_monitored: true },
  { id: uid(), name: 'Facebook', icon_key: 'facebook', color: '#1877F2', is_monitored: true },
];

const DEFAULT_SETTINGS: AppSettings = {
  focus_mode: 'strict',
  streak_count: 0,
  last_intake_date: null,
  theme: 'light',
  notifications_enabled: false,
};

// --- Init ---

export function initStore(): void {
  if (!localStorage.getItem(KEYS.meds)) write(KEYS.meds, DEFAULT_MEDICATIONS);
  if (!localStorage.getItem(KEYS.apps)) write(KEYS.apps, DEFAULT_APPS);
  if (!localStorage.getItem(KEYS.settings)) write(KEYS.settings, DEFAULT_SETTINGS);
  if (!localStorage.getItem(KEYS.logs)) write(KEYS.logs, [] as IntakeLog[]);
}

// --- Medications ---

export function getMedications(): Medication[] {
  return read<Medication[]>(KEYS.meds, []);
}

export function saveMedication(med: Omit<Medication, 'id' | 'created_at'> & { id?: string }): Medication {
  const meds = getMedications();
  if (med.id) {
    const idx = meds.findIndex((m) => m.id === med.id);
    if (idx >= 0) {
      meds[idx] = { ...meds[idx], ...med } as Medication;
      write(KEYS.meds, meds);
      return meds[idx];
    }
  }
  const newMed: Medication = {
    ...med,
    id: uid(),
    created_at: new Date().toISOString(),
  } as Medication;
  meds.push(newMed);
  write(KEYS.meds, meds);
  return newMed;
}

export function deleteMedication(id: string): void {
  const meds = getMedications().filter((m) => m.id !== id);
  write(KEYS.meds, meds);
  const logs = getIntakeLogs().filter((l) => l.medication_id !== id);
  write(KEYS.logs, logs);
}

// --- Intake Logs ---

export function getIntakeLogs(): IntakeLog[] {
  return read<IntakeLog[]>(KEYS.logs, []).sort((a, b) =>
    new Date(b.taken_at).getTime() - new Date(a.taken_at).getTime(),
  );
}

export function addIntakeLog(log: Omit<IntakeLog, 'id' | 'created_at'>): IntakeLog {
  const logs = getIntakeLogs();
  const newLog: IntakeLog = {
    ...log,
    id: uid(),
    created_at: new Date().toISOString(),
  };
  logs.unshift(newLog);
  write(KEYS.logs, logs);
  return newLog;
}

export function isMedicationTakenToday(medId: string): boolean {
  const today = new Date().toDateString();
  return getIntakeLogs().some(
    (l) => l.medication_id === medId && l.status === 'taken' && new Date(l.taken_at).toDateString() === today,
  );
}

// --- Social Apps ---

export function getSocialApps(): SocialApp[] {
  return read<SocialApp[]>(KEYS.apps, []);
}

export function updateSocialApp(id: string, isMonitored: boolean): void {
  const apps = getSocialApps().map((a) => (a.id === id ? { ...a, is_monitored: isMonitored } : a));
  write(KEYS.apps, apps);
}

// --- Settings ---

export function getSettings(): AppSettings {
  return read<AppSettings>(KEYS.settings, DEFAULT_SETTINGS);
}

export function updateSettings(patch: Partial<AppSettings>): AppSettings {
  const current = getSettings();
  const updated = { ...current, ...patch };
  write(KEYS.settings, updated);
  return updated;
}

// --- Streak Logic ---

export function recordIntake(medId: string): void {
  const med = getMedications().find((m) => m.id === medId);
  if (!med) return;
  const today = new Date().toISOString().slice(0, 10);
  addIntakeLog({
    medication_id: med.id,
    medication_name: med.name,
    dosage: med.dosage,
    taken_at: new Date().toISOString(),
    photo_verified: true,
    verification_result: 'verified',
    status: 'taken',
  });
  const settings = getSettings();
  if (settings.last_intake_date !== today) {
    const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
    const newStreak = settings.last_intake_date === yesterday ? settings.streak_count + 1 : 1;
    updateSettings({ streak_count: newStreak, last_intake_date: today });
  }
}

export type { Frequency, MedicationColor };
