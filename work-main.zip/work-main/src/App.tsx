import { useState, useEffect, useRef, useCallback } from 'react';
import { JrhThemeProvider } from './lib/jrhTheme';
import { useMedicationSchedule } from './lib/useMedicationSchedule';
import { jrhAlarmEngine } from './lib/alarmClockEngine';
import { jrhNotifications } from './lib/notificationService';
import type { UpcomingDose } from './lib/jrhTypes';
import { JrhNavBar, type ScreenName } from './components/JrhNavBar';
import { JrhTodayScreen } from './components/JrhTodayScreen';
import { JrhMedsScreen } from './components/JrhMedsScreen';
import { JrhSettingsScreen } from './components/JrhSettingsScreen';
import { JrhAppBlockScreen } from './components/JrhAppBlockScreen';
import { JrhActiveAlarm } from './components/JrhActiveAlarm';
import { JrhVerifyScreen } from './components/JrhVerifyScreen';

function JrhAppInner() {
  const [screen, setScreen] = useState<ScreenName>('today');
  const [activeAlarmDose, setActiveAlarmDose] = useState<UpcomingDose | null>(null);
  const [showVerify, setShowVerify] = useState(false);
  const [snoozeUntilMap, setSnoozeUntilMap] = useState<Record<string, number>>({});
  const [appsUnlocked, setAppsUnlocked] = useState(false);

  const { meds, doses, loading, fetchMeds, markTaken } = useMedicationSchedule(activeAlarmDose ? activeAlarmDose.doseTime : null);
  const tickRef = useRef(0);
  const [, setForceTick] = useState(0);

  // Force re-render every 30 seconds to update countdowns
  useEffect(() => {
    const interval = setInterval(() => {
      tickRef.current += 1;
      setForceTick(tickRef.current);
    }, 30000);
    return () => clearInterval(interval);
  }, []);

  // Alarm scheduler — checks every 10 seconds if any dose is due
  useEffect(() => {
    const checkAlarms = () => {
      const now = Date.now();
      for (const dose of doses) {
        if (dose.taken || !dose.medication.active) continue;

        const snoozeKey = `${dose.medication.id}-${dose.doseTime.getTime()}`;
        const snoozeUntil = snoozeUntilMap[snoozeKey];
        if (snoozeUntil && snoozeUntil > now) continue;

        const diffMs = dose.doseTime.getTime() - now;
        if (diffMs <= 60000 && diffMs > -120 * 60 * 1000) {
          if (!activeAlarmDose || activeAlarmDose.medication.id !== dose.medication.id) {
            setActiveAlarmDose(dose);
            setAppsUnlocked(false);
            jrhNotifications.send(dose.medication.name, dose.medication.dosage);
          }
        }
      }
    };

    const interval = setInterval(checkAlarms, 10000);
    checkAlarms();
    return () => clearInterval(interval);
  }, [doses, activeAlarmDose, snoozeUntilMap]);

  const handleTriggerAlarm = useCallback((dose: UpcomingDose) => {
    setActiveAlarmDose(dose);
    setAppsUnlocked(false);
  }, []);

  const handleDismissAlarm = useCallback(() => {
    if (activeAlarmDose) {
      const snoozeKey = `${activeAlarmDose.medication.id}-${activeAlarmDose.doseTime.getTime()}`;
      setSnoozeUntilMap((prev) => ({ ...prev, [snoozeKey]: Date.now() + 30 * 60 * 1000 }));
    }
    setActiveAlarmDose(null);
  }, [activeAlarmDose]);

  const handleSnooze = useCallback(() => {
    if (activeAlarmDose) {
      const snoozeKey = `${activeAlarmDose.medication.id}-${activeAlarmDose.doseTime.getTime()}`;
      setSnoozeUntilMap((prev) => ({ ...prev, [snoozeKey]: Date.now() + 5 * 60 * 1000 }));
    }
    setActiveAlarmDose(null);
  }, [activeAlarmDose]);

  const handleVerify = useCallback(() => {
    setShowVerify(true);
  }, []);

  const handleVerified = useCallback(async () => {
    if (activeAlarmDose) {
      jrhAlarmEngine.stop();
      jrhAlarmEngine.playSuccess();
      await markTaken(activeAlarmDose.medication.id);
      setAppsUnlocked(true);
    }
    setShowVerify(false);
    setActiveAlarmDose(null);
  }, [activeAlarmDose, markTaken]);

  const handleCancelVerify = useCallback(() => {
    setShowVerify(false);
    if (activeAlarmDose) {
      jrhAlarmEngine.start({ sound: true, vibration: true });
    }
  }, [activeAlarmDose]);

  const handleMarkTaken = useCallback(async (dose: UpcomingDose) => {
    jrhAlarmEngine.playConfirm();
    await markTaken(dose.medication.id);
    setAppsUnlocked(true);
  }, [markTaken]);

  // Verify from the Focus/Blocking screen (no active alarm)
  const handleVerifyFromFocus = useCallback(() => {
    setShowVerify(true);
  }, []);

  const pendingAlarmCount = doses.filter((d) => d.isOverdue && !d.taken).length;

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-white">
      {screen === 'today' && (
        <JrhTodayScreen
          doses={doses}
          loading={loading}
          onAddMedication={() => setScreen('medications')}
          onTriggerAlarm={handleTriggerAlarm}
          onMarkTaken={handleMarkTaken}
        />
      )}
      {screen === 'medications' && (
        <JrhMedsScreen meds={meds} loading={loading} onRefresh={fetchMeds} />
      )}
      {screen === 'focus' && (
        <JrhAppBlockScreen appsUnlocked={appsUnlocked} onVerify={handleVerifyFromFocus} />
      )}
      {screen === 'settings' && <JrhSettingsScreen />}

      <JrhNavBar
        current={screen}
        onNavigate={setScreen}
        pendingAlarmCount={pendingAlarmCount}
        appsUnlocked={appsUnlocked}
      />

      {/* Full-screen alarm overlay */}
      {activeAlarmDose && !showVerify && (
        <JrhActiveAlarm
          medication={activeAlarmDose.medication}
          doseTime={activeAlarmDose.doseTime}
          onDismiss={handleDismissAlarm}
          onSnooze={handleSnooze}
          onVerify={handleVerify}
        />
      )}

      {/* AI verification overlay — works with or without active alarm */}
      {showVerify && (
        <JrhVerifyScreen
          medication={activeAlarmDose?.medication ?? meds[0] ?? fallbackMed}
          onVerified={handleVerified}
          onCancel={handleCancelVerify}
        />
      )}
    </div>
  );
}

const fallbackMed = {
  id: 'manual',
  name: 'Your medication',
  dosage: 'As prescribed',
  scheduled_time: '08:00',
  frequency: 'daily',
  notes: null,
  color_hex: '#10b981',
  active: true,
  last_taken_at: null,
  created_at: '',
  updated_at: '',
};

export default function App() {
  return (
    <JrhThemeProvider>
      <JrhAppInner />
    </JrhThemeProvider>
  );
}
