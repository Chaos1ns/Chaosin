import { useEffect, useState, useCallback } from 'react';
import { jrhSupabase } from './supabaseClient';
import type { MedicationRecord, UpcomingDose } from './jrhTypes';
import { FREQUENCY_OPTIONS } from './jrhTypes';

/** Calculate all dose times for a medication today */
function computeDoseTimes(med: MedicationRecord): Date[] {
  const freq = FREQUENCY_OPTIONS.find((f) => f.value === med.frequency) ?? FREQUENCY_OPTIONS[0];
  const [hours, minutes] = med.scheduled_time.split(':').map(Number);
  const baseTime = new Date();
  baseTime.setHours(hours, minutes, 0, 0);

  if (freq.value === 'weekly') return [baseTime];

  return freq.intervals.map((offset) => {
    const d = new Date(baseTime);
    d.setHours(hours + offset, minutes, 0, 0);
    return d;
  });
}

function isSameHourMinute(a: Date, b: Date): boolean {
  return a.getHours() === b.getHours() && a.getMinutes() === b.getMinutes();
}

export function useMedicationSchedule(activeAlarmTime: Date | null) {
  const [meds, setMeds] = useState<MedicationRecord[]>([]);
  const [doses, setDoses] = useState<UpcomingDose[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchMeds = useCallback(async () => {
    const { data, error } = await jrhSupabase
      .from('medications')
      .select('*')
      .order('scheduled_time', { ascending: true });

    if (error) {
      setLoading(false);
      return;
    }
    setMeds((data as MedicationRecord[]) ?? []);
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchMeds();
  }, [fetchMeds]);

  useEffect(() => {
    if (meds.length === 0) {
      setDoses([]);
      return;
    }

    const now = new Date();
    const todayDoses: UpcomingDose[] = [];

    for (const med of meds) {
      if (!med.active) continue;
      const times = computeDoseTimes(med);
      for (const doseTime of times) {
        const minutesUntil = Math.round((doseTime.getTime() - now.getTime()) / 60000);
        const isOverdue = minutesUntil < 0 && minutesUntil > -120;

        // Check if already taken (last_taken_at within last 30 min of this dose time)
        let taken = false;
        if (med.last_taken_at) {
          const takenDate = new Date(med.last_taken_at);
          const diffMin = Math.abs(takenDate.getTime() - doseTime.getTime()) / 60000;
          if (diffMin < 35 && takenDate.getTime() > doseTime.getTime() - 60 * 60 * 1000) {
            taken = true;
          }
        }

        todayDoses.push({
          medication: med,
          doseTime,
          isOverdue: isOverdue && !taken,
          minutesUntil,
          taken,
        });
      }
    }

    todayDoses.sort((a, b) => a.doseTime.getTime() - b.doseTime.getTime());
    setDoses(todayDoses);
  }, [meds, activeAlarmTime]);

  /** Mark a medication as taken now */
  const markTaken = useCallback(async (medId: string) => {
    await jrhSupabase
      .from('medications')
      .update({ last_taken_at: new Date().toISOString(), updated_at: new Date().toISOString() })
      .eq('id', medId);
    await fetchMeds();
  }, [fetchMeds]);

  return { meds, doses, loading, fetchMeds, markTaken };
}

export { computeDoseTimes, isSameHourMinute };
